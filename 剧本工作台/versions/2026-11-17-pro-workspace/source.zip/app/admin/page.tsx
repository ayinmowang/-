import { chatGPTSignInPath, getChatGPTUser } from '../chatgpt-auth';
import { bindings, connected } from '../../lib/server';

export const dynamic = 'force-dynamic';

export default async function AdminPage() {
  const user = await getChatGPTUser();
  const env = bindings();
  const adminId = String(env.STUDIO_ADMIN_USER_ID || '').trim();
  const adminEmail = String(env.STUDIO_ADMIN_EMAIL || '').trim().toLowerCase();
  const canManage = Boolean(user && (
    (adminId && user.userId === adminId) ||
    (adminEmail && user.email.toLowerCase() === adminEmail)
  ));

  return (
    <main className="admin-shell">
      <section className="workspace-hud">
        <a className="workspace-download" href="/">← 返回总编剧工作台</a>
        <h1>管理后台</h1>
        {!user ? (
          <a className="workspace-download" href={chatGPTSignInPath('/admin')}>登录后台</a>
        ) : !canManage ? (
          <p>此页面需要工作台管理员权限。</p>
        ) : (
          <dl className="admin-status">
            <dt>创作服务</dt>
            <dd>{connected() ? '连接参数已配置' : '待配置连接参数'}</dd>
            <dt>模型与 Skill</dt>
            <dd>在创作服务端配置。</dd>
          </dl>
        )}
      </section>
    </main>
  );
}
