import type { Project, RemoteState, StudioMessage, WorkflowCard } from './types';

import { env } from 'cloudflare:workers';
import { getChatGPTUser } from '../app/chatgpt-auth';

export function bindings(): any {
  return env;
}

export async function owner(): Promise<string> {
  const user = await getChatGPTUser();
  if (!user) throw new Error('AUTH_REQUIRED');
  return user.userId;
}

export function connected(): boolean {
  const b = bindings();
  return Boolean((b.STUDIO_BACKEND_URL || b.DRAMA_API_URL || process.env.STUDIO_BACKEND_URL)
    && (b.STUDIO_BACKEND_TOKEN || b.DRAMA_API_TOKEN || process.env.STUDIO_BACKEND_TOKEN));
}

export function gptAvailable(): boolean {
  const b = bindings();
  return Boolean(b.OPENAI_API_KEY || process.env.OPENAI_API_KEY);
}

export function connectionMode(): 'remote' | 'gpt_test' | 'local' {
  if (connected()) return 'remote';
  if (gptAvailable()) return 'gpt_test';
  return 'local';
}

const SENSITIVE_KEYS = new Set([
  'model',
  'model_name',
  'provider',
  'route',
  'line',
  'tokens',
  'prompt_tokens',
  'completion_tokens',
  'total_tokens',
  'system_prompt',
  'raw_prompt',
  'api_key',
]);

/**
 * Redline filter: User-facing pages, API responses, errors, and exports MUST NEVER expose
 * model names, route names, token counts, or raw system prompts.
 */
export function sanitizeForClient<T>(input: T): T {
  if (input === null || input === undefined) return input;
  if (typeof input === 'string') {
    return input
      .replace(/\b(gpt-4[a-z0-9.-]*|gpt-5[a-z0-9.-]*|claude-[a-z0-9.-]+|gemini-[a-z0-9.-]+|deepseek-[a-z0-9.-]+|grok-[a-z0-9.-]+)\b/gi, '创作引擎')
      .replace(/\b(prompt_tokens|completion_tokens|total_tokens)\s*[:=]\s*\d+/gi, '') as unknown as T;
  }
  if (Array.isArray(input)) {
    return input.map((item) => sanitizeForClient(item)) as unknown as T;
  }
  if (typeof input === 'object') {
    const out: Record<string, any> = {};
    for (const [k, v] of Object.entries(input as Record<string, any>)) {
      if (SENSITIVE_KEYS.has(k.toLowerCase())) continue;
      out[k] = sanitizeForClient(v);
    }
    return out as T;
  }
  return input;
}

export async function getProject(id: string, user: string): Promise<Project> {
  if (!id) throw new Error('INVALID_INPUT');
  const row = await bindings()
    .DB.prepare('SELECT data,version FROM studio_projects WHERE id=? AND owner=?')
    .bind(id, user)
    .first();
  if (!row) throw new Error('NOT_FOUND');
  const parsed: Project = JSON.parse(row.data);
  parsed.version = row.version;
  // Backward compatibility defaults for legacy projects
  if (!Array.isArray(parsed.messages)) parsed.messages = [];
  if (!Array.isArray(parsed.attachments)) parsed.attachments = [];
  if (!Array.isArray(parsed.requirements)) parsed.requirements = [];
  if (parsed.lockedEpisodes === undefined) parsed.lockedEpisodes = null;
  if (parsed.startEpisode === undefined) parsed.startEpisode = parsed.lockedEpisodes ? parsed.lockedEpisodes + 1 : 1;
  if (parsed.budgetCap === undefined) parsed.budgetCap = 1.5;
  if (parsed.budgetUsed === undefined) parsed.budgetUsed = 0;
  return parsed;
}

export async function saveProject(p: Project, user: string): Promise<Project> {
  const now = new Date().toISOString();
  p.updatedAt = now;
  p.version = (p.version || 1) + 1;
  const clean = sanitizeForClient(p);
  const result = await bindings()
    .DB.prepare('UPDATE studio_projects SET data=?,version=?,updated_at=? WHERE id=? AND owner=? AND version=?')
    .bind(JSON.stringify(clean), clean.version, now, clean.id, user, clean.version - 1)
    .run();
  if (!result.meta.changes) throw new Error('CONFLICT');
  return clean;
}

export function message(
  p: Project,
  role: StudioMessage['role'],
  text: string,
  extra: Partial<StudioMessage> = {}
): StudioMessage {
  const msg: StudioMessage = {
    id: crypto.randomUUID(),
    role,
    text: sanitizeForClient(text),
    time: new Date().toISOString(),
    ...extra,
  };
  p.messages.push(msg);
  return msg;
}

export async function backend(
  path: string,
  method = 'GET',
  body?: any,
  rawBuffer = false
): Promise<Response> {
  const b = bindings();
  const baseUrl = String(b.STUDIO_BACKEND_URL || b.DRAMA_API_URL || process.env.STUDIO_BACKEND_URL || '').replace(/\/+$/, '');
  if (!baseUrl) throw new Error('SERVICE_NOT_CONNECTED');
  const headers: Record<string, string> = {};
  const token = b.STUDIO_BACKEND_TOKEN || b.DRAMA_API_TOKEN || process.env.STUDIO_BACKEND_TOKEN;
  if (token) headers['Authorization'] = `Bearer ${token}`;
  if (body !== undefined && !rawBuffer) headers['Content-Type'] = 'application/json';
  const res = await fetch(baseUrl + path, {
    method,
    headers,
    body: body === undefined ? undefined : rawBuffer ? body : JSON.stringify(body),
  });
  if (!res.ok) {
    const payload = await res.json().catch(() => null) as { error?: { code?: string } } | null;
    const code = payload?.error?.code;
    if (code === 'STALE_CARD') throw new Error('CONFLICT');
    if (code && ['TRANSCRIBE_SCOPE_REQUIRED', 'TRANSCRIBE_ALREADY_RUNNING', 'EPISODE_MAPPING_REQUIRED',
      'NO_PENDING_EPISODES', 'DELIVERY_NOT_READY'].includes(code)) throw new Error(code);
    throw new Error('BACKEND_REQUEST_FAILED');
  }
  return res;
}

export async function backendEpisodeFile(link: string): Promise<Response> {
  const b = bindings();
  const base = b.STUDIO_BACKEND_URL || b.DRAMA_API_URL || process.env.STUDIO_BACKEND_URL;
  if (!base) throw new Error('SERVICE_NOT_CONNECTED');
  const origin = new URL(base).origin;
  let target: URL;
  try { target = new URL(link, origin); }
  catch { throw new Error('NOT_FOUND'); }
  if (target.origin !== origin || target.username || target.password
    || !target.pathname.startsWith('/api/') || /%2f|%5c|%2e/i.test(target.pathname)) throw new Error('NOT_FOUND');
  const token = b.STUDIO_BACKEND_TOKEN || b.DRAMA_API_TOKEN || process.env.STUDIO_BACKEND_TOKEN;
  const response = await fetch(target, { redirect: 'manual', headers: token ? { Authorization: `Bearer ${token}` } : {} });
  if (!response.ok || !response.body || !/^(application\/(octet-stream|vnd\.openxmlformats-officedocument\.wordprocessingml\.document))(?:;|$)/i.test(response.headers.get('content-type') || '')) {
    throw new Error('TRANSCRIBE_FILE_UNAVAILABLE');
  }
  return response;
}

export function failure(e: any): Response {
  const code = String(e?.message || 'REQUEST_FAILED');
  const statusMap: Record<string, number> = {
    AUTH_REQUIRED: 401,
    NOT_FOUND: 404,
    CONFLICT: 409,
    INVALID_INPUT: 400,
    FILE_TOO_LARGE: 413,
    EPISODE_ALREADY_USED: 400,
    EPISODE_MAPPING_REQUIRED: 400,
    MODE_SELECTION_REQUIRED: 400,
    UNDERSTOOD_GATE_REQUIRED: 400,
    BUDGET_EXCEEDED: 402,
    SERVICE_NOT_CONNECTED: 503,
    BACKEND_REQUEST_FAILED: 502,
    TRANSCRIBE_SCOPE_UNAVAILABLE: 409,
    TRANSCRIBE_ALREADY_RUNNING: 409,
    TRANSCRIBE_FILE_UNAVAILABLE: 502,
    TRANSCRIBE_SCOPE_REQUIRED: 409,
    NO_PENDING_EPISODES: 422,
    DELIVERY_NOT_READY: 409,
  };
  return Response.json(
    { error: Object.hasOwn(statusMap, code) ? code : 'REQUEST_FAILED' },
    { status: statusMap[code] || 500 }
  );
}
