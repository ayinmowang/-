import type { Project, RemoteState, TranscribeDelivery } from './types';

export const deliveryActions = { single: 'extract_episode', all: 'extract_all_episodes' } as const;
export type DeliveryScope = keyof typeof deliveryActions;

export function supportsDelivery(state: RemoteState | undefined, scope: DeliveryScope) {
  const action = deliveryActions[scope];
  return Boolean(state && (state.transcribeActions?.includes(action) || state.card?.actions?.some(item => item.key === action)));
}

export function deliveryEpisodes(project: Project) {
  return [...new Set(project.attachments.map(item => item.episode).filter((value): value is number =>
    Number.isInteger(value) && value! > 0 && value! <= (project.total ?? 300)))].sort((a, b) => a - b);
}

export function transcribeIssue(state?: RemoteState) {
  if (state?.transcribeError === 'INVALID_RECORD') return '当前集的核验记录缺少必需字段。可从失败步骤重试，已交付的正文仍可下载。';
  if (state?.transcribeError === 'OUTPUT_TRUNCATED') return '当前集的核验记录未完整返回。可从失败步骤重试。';
  if (state?.transcribeError === 'MEDIA_UNAVAILABLE') return '当前集的媒体解析没有完成。可在解析服务恢复后重试。';
  return '';
}

export function deliveryAnswers(project: Project, state: RemoteState, scope: DeliveryScope, requested: unknown) {
  if (project.kind !== 'transcribe' || !project.confirmed) throw new Error('INVALID_INPUT');
  const mode = state.transcribeMode ?? project.transcribeMode;
  if (mode !== 'fast' && mode !== 'detailed') throw new Error('MODE_SELECTION_REQUIRED');
  if (!supportsDelivery(state, scope)) throw new Error('TRANSCRIBE_SCOPE_UNAVAILABLE');
  if (state.status === 'running' || state.status === 'ready' || state.status === 'paused') throw new Error('TRANSCRIBE_ALREADY_RUNNING');
  const episodes = deliveryEpisodes(project);
  if (!episodes.length || episodes.length !== project.attachments.length) {
    throw new Error('EPISODE_MAPPING_REQUIRED');
  }
  if (scope === 'single' && (typeof requested !== 'number' || !episodes.includes(requested))) {
    throw new Error('INVALID_INPUT');
  }
  return { mode, episode: scope === 'single' ? requested as number : undefined, batch_size: 3, deliver_per_episode: true, preserve_completed: true };
}

export function episodeDeliveries(state?: RemoteState) {
  const deliveries = new Map<number, TranscribeDelivery>();
  const candidates = [...(state?.episodeDeliveries ?? []),
    ...(state?.messages ?? []).flatMap(item => item.file?.episode ? [{ ...item.file, episode: item.file.episode }] : [])];
  for (const item of candidates) {
    if (!Number.isInteger(item.episode) || item.episode < 1 || item.episode > 300
      || !item.url || typeof item.name !== 'string' || !/\.docx$/i.test(item.name)) continue;
    const existing = deliveries.get(item.episode);
    if (!existing || (item.version ?? 0) >= (existing.version ?? 0)) deliveries.set(item.episode, item);
  }
  return [...deliveries.values()].sort((a, b) => a.episode - b.episode);
}
