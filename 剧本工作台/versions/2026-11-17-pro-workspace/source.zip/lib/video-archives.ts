export const VIDEO_FILENAME = /\.(mp4|mov|webm)$/i;
export const VIDEO_UPLOAD_LIMIT = 20 * 1024 * 1024;
const ARCHIVE_LIMIT = 160 * 1024 * 1024;
const VIDEO_MIME: Record<string, string> = {
  mp4: 'video/mp4',
  mov: 'video/quicktime',
  webm: 'video/webm',
};

export async function extractVideoArchives(files: File[]): Promise<File[]> {
  const { unzipSync } = await import('fflate');
  const sources: File[] = [];
  let extractedBytes = 0;

  for (const file of files) {
    if (!/\.zip$/i.test(file.name)) {
      sources.push(file);
      continue;
    }

    if (file.size > ARCHIVE_LIMIT) throw new Error('ZIP_TOO_LARGE');
    let entryCount = 0;
    const contents = unzipSync(new Uint8Array(await file.arrayBuffer()), {
      filter(entry) {
        const name = entry.name.split('/').at(-1) || '';
        if (entry.name.startsWith('__MACOSX/') || name.startsWith('.') || !VIDEO_FILENAME.test(name)) return false;
        if (Math.max(entry.size, entry.originalSize) > VIDEO_UPLOAD_LIMIT) throw new Error('FILE_TOO_LARGE');
        entryCount += 1;
        extractedBytes += Math.max(entry.size, entry.originalSize);
        if (sources.length + entryCount > 300 || extractedBytes > ARCHIVE_LIMIT) throw new Error('ZIP_TOO_LARGE');
        return true;
      },
    });

    if (!Object.keys(contents).length) throw new Error('ZIP_NO_VIDEOS');
    for (const [path, data] of Object.entries(contents)) {
      const name = path.split('/').at(-1)!;
      const extension = name.split('.').at(-1)!.toLowerCase();
      sources.push(new File([new Uint8Array(data)], name, { type: VIDEO_MIME[extension] }));
    }
  }

  return sources;
}
