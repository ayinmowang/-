# 总编剧 · AI 短剧工作台

一个以「总编剧」为统一入口的聊天式短剧创作网站。用户选定扒剧、国外迭代国外、国内迭代国外或原创流程，上传材料、用自然语言交代要求、核对复述、在阶段卡片上拍板，并在同一项目会话里获取产物。

线上网站：<https://director-studio-ayin.ayinx.chatgpt.site/>。当前为私有站点，需要有权限的 ChatGPT 账号访问。

## 仓库结构

| 路径 | 用途 |
| --- | --- |
| `app/`、`lib/`、`db/` | Vinext 网页、Worker API、D1 与 R2 数据层 |
| `backend/` | Python FastAPI 创作流程、GPT 连接器及测试 |
| `docs/计划书_v1.md` | 用户原始整改计划 |
| `docs/网站计划书.md` | 网站实施计划 |
| `docs/项目书.md` | 正式项目书 |
| `docs/设计审查.md` | 本轮交互检查与尚待验证事项 |
| `.openai/hosting.json` | 当前 Sites 项目和存储绑定 |

请先读 `docs/计划书_v1.md` 与 `docs/项目书.md`。用户已拍板的流程、停点、费用边界和信息保密要求不能自行改动；建议与变更应单独提出。

## 本地开发

网页要求 Node.js 22.13+。安装 `npm ci`，运行 `npm run dev`，生产构建用 `npm run build`，类型检查用 `npx tsc --noEmit`。本地预览的登录和 D1/R2 配置取决于 Sites 运行环境；不要把测试账号、素材或密钥提交到仓库。

后端要求 Python 3.11+。在 `backend/` 运行 `python3 -m venv .venv`、`pip install -r requirements.txt`，按 `backend/README.md` 配置环境变量，再运行 `uvicorn app.main:app --host 127.0.0.1 --port 8000 --workers 1`。后端确定性测试：`python3 -m unittest discover -s tests -v`。真实 GPT 测试需要显式设置 `RUN_GPT_TESTS=1`、测试额度和密钥，不使用用户真实素材。

网页连接后端需要部署环境设置 `DRAMA_API_URL` 和 `DRAMA_API_TOKEN`；后端的 `APP_TOKEN` 与后者对应。**当前线上环境尚未配置创作后端及 GPT 凭据**：可以建档、对话留档和上传素材，不能把网页部署成功当作四类流程端到端验收。

## 协作方式

同一账号中的智能体可以从本网站的 Sites 项目继续编辑源码；其他账号应由项目所有者添加适当的协作者权限。更通用的协作方式是在用户控制的 GitHub 等仓库建立镜像并使用分支或 PR，发布前将合并结果同步回当前 Sites 源码仓库。只分享网站链接不会自动授予源码编辑权。

`backend/app/providers.py` 预留原有媒体/API 的适配位，具体旧接口尚未提供。创建项目时后端仍要求总集数，原创流程的停点 A 才正式拍板集数；要完全一致，需要调整后端项目契约与动态流程计划，不能填一个虚假的默认集数。见 `docs/设计审查.md`。
