"""Deterministic commands first; ambiguous conversation goes to the configured GPT."""
import re
from .storage import uid, now, event

COMMANDS = {'通过': 'confirm', '对，开始': 'confirm', '开始': 'confirm',
            '通过，写下一集': 'confirm', '暂停': 'pause', '一键叫停': 'pause',
            '恢复': 'resume', '重试': 'retry', '写完吧': 'release_stops',
            '好，通过，写完吧': 'release_stops'}


def parse(text):
    normalized = text.strip().rstrip('。！!')
    if normalized in COMMANDS:
        return {'intent': 'action', 'action': COMMANDS[normalized], 'answers': {}}
    if normalized in ['快速', '快速模式', '详细', '详细模式']:
        return {'intent': 'action', 'action': 'confirm',
                'answers': {'mode': 'fast' if normalized.startswith('快速') else 'detailed'}}
    if normalized in ['咋样了', '进度', '现在进度', '什么时候好', '还要多久', '啥时候给我答复']:
        return {'intent': 'progress'}
    match = re.fullmatch(r'(背景|男女频|结局|风格)[：:=]\s*(.+)', normalized, re.S)
    if match:
        return {'intent': 'requirement', 'field': match[1], 'value': match[2]}
    if normalized.startswith(('加点', '加入', '增加', '加爱情', '不要', '必须', '要求：')):
        return {'intent': 'requirement', 'field': None, 'value': normalized}
    return {'intent': 'conversation'}


def reply(project, text):
    message = dict(id=uid(), role='director', text=text, at=now())
    project['messages'].append(message)
    event(project, 'text', message=message)


def add_requirement(project, text, field=None, value=None, conflicts_with=None):
    previous = next((r for r in reversed(project['requirements'])
                     if field and r.get('field') == field and r['status'] == 'active'), None)
    if conflicts_with:
        previous = next((r for r in project['requirements']
                         if r['id'] == conflicts_with and r['status'] == 'active'), previous)
    item = dict(id=uid(), text=text, at=now(), stage=project['steps'][project['cursor']]['key'],
                version=len(project['requirements']) + 1, status='active', field=field, value=value or text)
    project['requirements'].append(item)
    if previous and previous.get('value', previous['text']) != item['value']:
        item['status'] = 'pending'
        conflict = dict(id=uid(), old=previous['id'], new=item['id'], status='pending')
        project.setdefault('conflicts', []).append(conflict)
        event(project, 'conflict', conflict=conflict, old_text=previous['text'], new_text=text,
              options=['keep_old', 'use_new'])
        return '这条要求与已有要求冲突，请选择保留原要求或采用新要求。受影响的生成等待裁定。'
    return '已记入要求台账。用于后续生成；当前在途结果会停下供你核对。'
