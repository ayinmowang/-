"""Business gates are data. No UI or model may advance them implicitly."""

def step(key, title, gate=True, fields=(), **extra):
    return dict(key=key, title=title, gate=gate, fields=list(fields), **extra)


def plan(kind, total, start):
    steps = [step('recap', '复述确认', local=True)]
    if kind == 'transcribe':
        steps += [step('mode', '选择扒剧模式', fields=['mode'], local=True)]
        steps += [step(f'transcribe_{n}', f'扒剧第 {n} 集', gate=False, episode=n)
                  for n in range(start, total + 1)]
        steps += [step('synopsis', '全集梗概和人物小传', gate=False)]
    elif kind == 'original':
        steps += [step('reasoning', '原创前四层推理与停点 A',
                       fields=['direction', 'opening', 'engine', 'total', 'audience'])]
        if total is None:
            return steps
        steps += [step('synopsis', '设定集、梗概、人物与剧名')]
    else:
        steps += [step('analysis', '原稿分析、事件映射、错名和逐集情绪曲线',
                       fields=['alignment', 'peak', 'audience', 'unresolved', 'numbers'])]
        if kind == 'domestic':
            steps += [step('diagnosis', '桥段出海四级诊断')]
            steps += [step(key, title) for key, title in [
                ('world', '世界观确认'), ('characters', '人设确认'), ('replacements', '替换要点确认')]]
        steps += [step('configuration', '四项配置',
                       fields=['scope', 'background', 'ending', 'boundaries']),
                  step('proposals', '主线和对手方案 2–3 套', fields=['selection']),
                  step('mainline', '简化主线单与看得懂关', fields=['understood']),
                  step('synopsis', '梗概、人物小传和剧名')]
    if kind != 'transcribe':
        for n in range(start, total + 1, 10):
            steps.append(step(f'outline_{n}', f'第 {n}–{min(n + 9, total)} 集细纲',
                              gate=kind == 'original' or n == start,
                              episode=n, end=min(n + 9, total)))
        steps.append(step('outline_all', '全剧细纲确认及开正文', local=True))
        steps += [step(f'script_{n}', f'第 {n} 集正文', gate=n < start + 3, episode=n)
                  for n in range(start, total + 1)]
        for key, title in [('review', '初审'), ('ruling', '裁定'), ('revision', '返修'),
                           ('recheck', '复核'), ('polish', '台词精修')]:
            steps.append(step(key, title, gate=False))
        if kind == 'domestic':
            steps.append(step('localize', '北美语感和美式幽默精修', gate=False))
        steps.append(step('final_review', '终复核', gate=False))
    steps.append(step('delivery', '交付确认', local=True))
    return steps
