"""Lossless source packing by character capacity, independent of episode count."""
import os


def source_batches(attachments, capacity=None):
    capacity = capacity or max(1000, int(os.getenv('SOURCE_BATCH_CHARS', '12000')))
    batches, current, used = [], [], 0
    for attachment in attachments:
        text = attachment.get('text', '')
        offset = 0
        while offset < len(text):
            count = min(capacity - used, len(text) - offset)
            current.append(dict(name=attachment['name'], role=attachment['role'],
                                attachment_id=attachment['id'], start=offset, end=offset + count,
                                episode=attachment.get('episode'), text=text[offset:offset + count]))
            offset += count
            used += count
            if used == capacity:
                batches.append(current)
                current, used = [], 0
    if current:
        batches.append(current)
    return batches


def expand_analysis(project):
    stage = project['steps'][project['cursor']]
    if stage['key'] != 'analysis' or stage.get('assembled'):
        return
    batches = source_batches(project['attachments'])
    if len(batches) < 2:
        return
    parts = [dict(key=f'analysis_part_{i + 1}', title=f'原稿分析第 {i + 1}/{len(batches)} 批',
                  gate=False, fields=[], source_parts=batch)
             for i, batch in enumerate(batches)]
    assembled = dict(stage, local=True, assembled=True, parts=[part['key'] for part in parts])
    cursor = project['cursor']
    project['steps'][cursor:cursor + 1] = parts + [assembled]


def assemble_analysis(project, stage):
    parts = [project['outputs'][key] for key in stage['parts']]
    return dict(content=f'原稿已分 {len(parts)} 批分析完成，请核对逐批内容和待定事项。',
                parts=stage['parts'], scripts={}, understandable=True,
                questions=[q for part in parts for q in part.get('questions', [])],
                issues=[issue for part in parts for issue in part.get('issues', [])])
