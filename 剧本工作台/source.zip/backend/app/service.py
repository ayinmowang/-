import copy
import asyncio
import base64
import json
import math
import re
from .storage import uid, now, event
from .workflows import plan
from .providers import ProviderError
from .dialogue import parse, reply, add_requirement
from .batching import expand_analysis, assemble_analysis


class RuleError(Exception):
    def __init__(self, code, status=409):
        self.code, self.status = code, status


def current(project):
    return project['steps'][project['cursor']]


def card(project):
    stage = current(project)
    return dict(id=f"{project['id']}:{project['version']}", version=project['version'],
                stage=stage['key'], step=stage['key'], title=stage['title'], fields=stage['fields'],
                options=['confirm', 'revise'], choices={'mode': ['fast', 'detailed']} if stage['key'] == 'mode' else {}, questions=project['outputs'].get(stage['key'], {}).get('questions', []))


def transcription_deliveries(project):
    if project['kind'] != 'transcribe':
        return []
    return [dict(episode=n, version=project.get('transcribe_versions', {}).get(str(n), 1),
                 name=f'第 {n} 集.docx', url=f"/api/projects/{project['id']}/episodes/{n}/export")
            for n in sorted(map(int, project['scripts']))
            if str(n) not in project.get('transcribe_unapproved', [])]


def public(project):
    result = {key: project[key] for key in ['id', 'title', 'kind', 'total', 'start', 'status',
            'version', 'cursor', 'requirements', 'messages', 'attachments', 'updated_at']} | {
            'stage': current(project), 'card': card(project) if project['status'] == 'waiting' else None,
            'progress': {'completed_steps': project['cursor'], 'total_steps': len(project['steps']),
                         'eta_seconds': None, 'current_episode': current(project).get('episode')},
            'conflicts': project.get('conflicts', []),
            'lastError': next((e.get('code') for e in reversed(project['events']) if e['type'] == 'error'), None)
                if project['status'] == 'failed' else None,
            'outputs': project['outputs'], 'scripts': project['scripts'], 'locked': project['locked'],
            'budget': {k: project['budget'][k] for k in ['cap', 'spent', 'reserved']}}
    if project['kind'] == 'transcribe':
        mode = project['decisions'].get('mode', {}).get('mode')
        result.update(transcribeMode=mode, episodeDeliveries=transcription_deliveries(project),
                      transcribeError=project.get('transcribe_error'), transcribeFailures=project.get('transcribe_failures', {}),
                      transcribeActions=['extract_episode', 'extract_all_episodes'] if mode and project['status'] != 'delivered' else [])
        if project['status'] == 'waiting' and project.get('transcribe_waiting_scope'):
            result['card'] = None
    return result


class Service:
    def __init__(self, store, provider, media_adapter=None):
        self.store, self.provider, self.media_adapter = store, provider, media_adapter

    def create(self, title, kind, total, start=1, locked=None, brief='', transcribe_scope_choice=False):
        locked = locked or {}
        if set(locked) != {str(n) for n in range(1, start)}:
            raise RuleError('LOCKED_RANGE_REQUIRED', 422)
        project = dict(id=uid(), title=title, kind=kind, total=total, start=start, locked=locked,
            brief=brief, steps=plan(kind, total, start), cursor=0, version=1, status='waiting',
            messages=[], events=[], requirements=[], attachments=[], outputs={}, scripts={},
            decisions={}, actions={}, runs=[], fast_forward=False, paused=False, revisions={},
            budget={'cap': 0., 'spent': 0., 'reserved': 0.}, updated_at=now())
        if kind == 'transcribe':
            project['transcribe_scope_choice'] = transcribe_scope_choice
        self.recap(project)
        self.store.create(project)
        return public(project)

    def recap(self, p):
        scope = (f"全剧 {p['total']} 集，本轮第 {p['start']}–{p['total']} 集" if p['total'] else '总集数在停点 A 确认')
        text = (f"1. 流程 {p['kind']}，{scope}。\n"
                f"2. 已锁定 {len(p['locked'])} 集，按原文保留。\n"
                f"3. 文件 {[(a['name'], a['role'], a.get('episode')) for a in p['attachments']]}。\n"
                f"4. 本轮要求 {p['brief']}。请核对后确认。")
        p['outputs']['recap'] = {'content': text, 'questions': [], 'issues': []}
        event(p, 'card', card=card(p), content=text)

    def message(self, pid, client_id, text):
        with self.store.transaction(pid) as p:
            for m in p['messages']:
                if m.get('client_id') == client_id:
                    if m['text'] != text:
                        raise RuleError('IDEMPOTENCY_CONFLICT')
                    return m
            msg = dict(id=uid(), client_id=client_id, role='user', text=text, at=now())
            p['messages'].append(msg)
            event(p, 'text', message=msg)
            intent = parse(text)
            if intent['intent'] == 'progress':
                reply(p, f"当前处于{current(p)['title']}，状态 {p['status']}，已完成 {p['cursor']} 步。暂无可靠预计时间。")
            elif intent['intent'] == 'requirement' and p['status'] != 'delivered':
                reply(p, add_requirement(p, text, intent['field'], intent['value']))
            else:
                p.setdefault('inbox', []).append(dict(id=msg['id'], text=text, intent=intent,
                    version=p['version'], status='pending', stage=current(p)['key']))
                reply(p, '收到，正在处理你的消息。')
            return msg

    def approve_budget(self, pid, cap):
        with self.store.transaction(pid) as p:
            if cap < p['budget']['spent'] + p['budget']['reserved']:
                raise RuleError('CAP_BELOW_COMMITTED')
            p['budget']['cap'] = cap
            event(p, 'report', content='本项目生成额度已更新。')

    def action(self, pid, version, action_id, action, answers):
        signature = json.dumps([version, action, answers], sort_keys=True, ensure_ascii=False)
        with self.store.transaction(pid) as p:
            previous = p['actions'].get(action_id)
            if previous:
                if previous['signature'] != signature:
                    raise RuleError('IDEMPOTENCY_CONFLICT')
                return previous['result']
            if version != p['version']:
                raise RuleError('STALE_CARD')
            if p['status'] == 'delivered':
                raise RuleError('PROJECT_LOCKED')
            if action == 'pause':
                p['paused'] = True
                if p['status'] != 'running' and p['status'] != 'paused':
                    p['resume_status'] = p['status']
                    p['status'] = 'paused'
            elif action == 'resume':
                if not p['paused']:
                    raise RuleError('NOT_PAUSED')
                p['paused'] = False
                if p['status'] == 'paused':
                    p['status'] = p.get('resume_status', 'waiting')
            elif action == 'retry':
                if p['status'] != 'failed':
                    raise RuleError('NOT_FAILED')
                p.pop('transcribe_error', None)
                p['status'] = 'ready'
            elif action in ('extract_episode', 'extract_all_episodes'):
                self.start_transcription(p, action, answers)
            elif action == 'release_stops':
                if not current(p)['key'].startswith('script_'):
                    raise RuleError('BODY_STAGE_REQUIRED')
                p['fast_forward'] = True
                if p['status'] == 'waiting':
                    self.confirm(p, answers)
            else:
                if p['status'] != 'waiting' or p['paused']:
                    raise RuleError('NOT_WAITING')
                stage = current(p)
                if action == 'revise':
                    if not answers.get('feedback'):
                        raise RuleError('FEEDBACK_REQUIRED', 422)
                    p['requirements'].append(dict(id=uid(), text=answers['feedback'], at=now(),
                        stage=stage['key'], version=len(p['requirements']) + 1, status='active'))
                    p['revisions'][stage['key']] = p['revisions'].get(stage['key'], 0) + 1
                    if stage['key'] == 'delivery':
                        target = answers.get('episode')
                        if target is None or str(target) not in p['scripts']:
                            raise RuleError('UNLOCKED_EPISODE_REQUIRED', 422)
                        prefix = 'transcribe_' if p['kind'] == 'transcribe' else 'script_'
                        p['cursor'] = next(i for i, entry in enumerate(p['steps']) if entry['key'] == prefix + str(target))
                        p['status'] = 'ready'
                    else:
                        p['status'] = 'ready' if not stage.get('local') else 'waiting'
                elif action == 'confirm':
                    self.confirm(p, answers)
                else:
                    raise RuleError('UNKNOWN_ACTION', 422)
            p['version'] += 1
            event(p, 'state', status=p['status'], stage=current(p)['key'])
            if p['status'] == 'waiting':
                event(p, 'card', card=card(p))
            result = public(p)
            p['actions'][action_id] = {'signature': signature, 'result': result}
            return result

    def confirm(self, p, answers):
        stage = current(p)
        if p.get('transcribe_waiting_scope'):
            raise RuleError('TRANSCRIBE_SCOPE_REQUIRED', 422)
        if any(c['status'] == 'pending' for c in p.get('conflicts', [])):
            raise RuleError('REQUIREMENT_CONFLICT_PENDING')
        for field in stage['fields']:
            if answers.get(field) in [None, '']:
                raise RuleError('ANSWER_REQUIRED_' + field.upper(), 422)
        if stage['key'] == 'recap':
            if p['kind'] != 'original' and not p['attachments']:
                raise RuleError('SOURCE_REQUIRED')
            if p['kind'] == 'original' and not (p['brief'] or p['requirements']):
                raise RuleError('BRIEF_REQUIRED')
            if p['kind'] == 'transcribe':
                episodes = [a.get('episode') for a in p['attachments'] if a['role'] == 'source']
                if sorted(e for e in episodes if e) != list(range(p['start'], p['total'] + 1)):
                    raise RuleError('EPISODE_MAPPING_REQUIRED')
        if stage['key'] == 'mode' and answers.get('mode') not in ['fast', 'detailed']:
            raise RuleError('MODE_REQUIRED', 422)
        if stage['key'] == 'reasoning':
            value = str(answers['total']).strip()
            if not re.fullmatch(r'[1-9][0-9]{0,2}', value) or not p['start'] <= int(value) <= 300:
                raise RuleError('INVALID_EPISODE_COUNT', 422)
            p['total'] = int(value)
            p['steps'] = plan('original', p['total'], p['start'])
        if stage['key'] == 'mainline' and (answers['understood'] is not True or
                not p['outputs'].get('mainline', {}).get('understandable')):
            raise RuleError('UNDERSTANDING_GATE_FAILED')
        output = p['outputs'].get(stage['key'], {})
        if output.get('issues') and not answers.get('resolution'):
            raise RuleError('ISSUE_RESOLUTION_REQUIRED')
        if output.get('questions') and not answers.get('decisions'):
            raise RuleError('QUESTION_DECISIONS_REQUIRED')
        p['decisions'][stage['key']] = answers
        if stage['key'] == 'delivery':
            p['status'] = 'delivered'
            return
        p['cursor'] += 1
        if stage['key'] == 'mode' and (p.get('transcribe_scope_choice') or answers.get('choose_scope') is True):
            p['transcribe_waiting_scope'] = True
            p['status'] = 'waiting'
            return
        if stage['key'].startswith('transcribe_'):
            n = str(stage['episode'])
            pending = p.setdefault('transcribe_unapproved', [])
            if n in pending:
                pending.remove(n)
            if p.get('transcribe_queue') is not None:
                self.advance_transcription(p)
                return
        self.enter(p)

    def start_transcription(self, p, action, answers):
        if p['kind'] != 'transcribe' or not p['decisions'].get('mode', {}).get('mode'):
            raise RuleError('MODE_SELECTION_REQUIRED', 422)
        if p['status'] in ('running', 'ready') or p['paused']:
            raise RuleError('TRANSCRIBE_ALREADY_RUNNING')
        if any(c['status'] == 'pending' for c in p.get('conflicts', [])):
            raise RuleError('REQUIREMENT_CONFLICT_PENDING')
        available = sorted({a['episode'] for a in p['attachments'] if a['role'] == 'source' and a.get('episode')})
        delivered = {item['episode'] for item in transcription_deliveries(p)}
        if action == 'extract_episode':
            episode = answers.get('episode')
            if type(episode) is not int or episode not in available:
                raise RuleError('EPISODE_MAPPING_REQUIRED', 422)
            episodes = [episode]
        else:
            episodes = [episode for episode in available if episode not in delivered]
        if not episodes:
            if action == 'extract_all_episodes' and len(delivered) == p['total'] - p['start'] + 1 and 'synopsis' not in p['outputs']:
                p['transcribe_waiting_scope'] = False
                p['cursor'] = next(i for i, stage in enumerate(p['steps']) if stage['key'] == 'synopsis')
                self.enter(p)
                return
            raise RuleError('NO_PENDING_EPISODES', 422)
        p['transcribe_queue'] = episodes
        p['transcribe_group_remaining'] = min(3, len(episodes))
        p['transcribe_scope'] = 'single' if action == 'extract_episode' else 'all'
        p['transcribe_waiting_scope'] = False
        p.pop('transcribe_error', None)
        self.select_transcription(p, episodes[0])

    def select_transcription(self, p, episode):
        p['cursor'] = next(i for i, stage in enumerate(p['steps']) if stage['key'] == f'transcribe_{episode}')
        p['status'] = 'ready'

    def advance_transcription(self, p):
        self.consume_transcription(p)
        if p['transcribe_queue']:
            self.select_transcription(p, p['transcribe_queue'][0])
        elif p['transcribe_scope'] == 'all' and len(transcription_deliveries(p)) == p['total'] - p['start'] + 1:
            p.pop('transcribe_queue')
            p['cursor'] = next(i for i, stage in enumerate(p['steps']) if stage['key'] == 'synopsis')
            self.enter(p)
        else:
            p.pop('transcribe_queue')
            p['transcribe_waiting_scope'] = True
            p['status'] = 'waiting'

    def consume_transcription(self, p):
        p['transcribe_queue'].pop(0)
        p['transcribe_group_remaining'] = p.get('transcribe_group_remaining', 1) - 1
        if p['transcribe_queue'] and p['transcribe_group_remaining'] == 0:
            group = p['transcribe_queue'][:3]
            p['transcribe_group_remaining'] = len(group)
            event(p, 'progress', content=f"开始下一组：第 {'、'.join(map(str, group))} 集。")

    def enter(self, p):
        stage = current(p)
        if stage.get('assembled'):
            p['outputs'][stage['key']] = assemble_analysis(p, stage)
        p['status'] = 'waiting' if stage.get('local') else 'ready'
        if stage['key'] == 'delivery':
            missing = set(map(str, range(1, p['total'] + 1))) - (p['locked'].keys() | p['scripts'].keys())
            if missing:
                raise RuleError('MISSING_EPISODES')
            event(p, 'file', name='screenplay.zip' if p['kind'] == 'transcribe' else 'screenplay.docx',
                  url=f"/api/projects/{p['id']}/export")
        if p['status'] == 'waiting':
            event(p, 'card', card=card(p))

    def payload(self, p):
        stage = current(p)
        episode = stage.get('episode') if stage['key'].startswith('transcribe_') else None
        transcription_summary = p['kind'] == 'transcribe' and stage['key'] == 'synopsis'
        sources = []
        for a in p['attachments']:
            if transcription_summary:
                break
            if episode is not None and (a.get('episode') != episode or a['role'] != 'source'):
                continue
            sources.append(dict(name=a['name'], role=a['role'], episode=a.get('episode'),
                                text=a.get('text', '')))
        if current(p).get('source_parts'):
            sources = current(p)['source_parts']
        return dict(stage={k: v for k, v in stage.items() if k != 'source_parts'}, brief=p['brief'], total=p['total'], start=p['start'],
                    locked=p['locked'], sources=sources, requirements=[r for r in p['requirements'] if r['status'] == 'active'],
                    decisions=p['decisions'], outputs={} if episode is not None or transcription_summary or stage.get('source_parts') else p['outputs'],
                    scripts={str(episode - 1): p['scripts'][str(episode - 1)]} if episode is not None and str(episode - 1) in p['scripts']
                    else {} if episode is not None else p['scripts'])

    def transcription_failed(self, p, episode, code):
        p['transcribe_error'] = code
        p.setdefault('transcribe_failures', {})[str(episode)] = code
        p['status'] = 'failed'
        if p.get('transcribe_scope') == 'all' and p.get('transcribe_queue'):
            self.consume_transcription(p)
            if p['transcribe_queue']:
                self.select_transcription(p, p['transcribe_queue'][0])
                if p['paused']:
                    p['status'] = 'paused'
                    p['resume_status'] = 'ready'
            else:
                p.pop('transcribe_queue')
                p['transcribe_waiting_scope'] = True
                p['status'] = 'paused' if p['paused'] else 'waiting'
                p['resume_status'] = 'waiting'

    async def prepare_transcription(self, pid):
        with self.store.transaction(pid) as p:
            stage = current(p)
            if p['status'] != 'ready' or p['paused'] or not stage['key'].startswith('transcribe_'):
                return False
            attachment = next((a for a in p['attachments'] if a.get('episode') == stage['episode'] and a['role'] == 'source'), None)
            if not attachment or attachment.get('text'):
                return False
            if not self.media_adapter:
                return False
            p['status'] = 'running'
            mode = p['decisions']['mode']['mode']
            episode = stage['episode']
            attachment = copy.deepcopy(attachment)
        try:
            data = await asyncio.to_thread((self.store.root / attachment['id']).read_bytes)
            result = await self.media_adapter.execute('parse_media', {
                'project_id': pid, 'attachment_id': attachment['id'], 'episode': episode, 'mode': mode,
                'name': attachment['name'], 'data_base64': base64.b64encode(data).decode(),
            })
            text = result.get('text') if isinstance(result, dict) else None
            if not isinstance(text, str) or not text.strip():
                raise ValueError('Invalid media record')
        except Exception as exc:
            with self.store.transaction(pid) as p:
                self.transcription_failed(p, episode, 'INVALID_RECORD' if isinstance(exc, ValueError) else 'MEDIA_UNAVAILABLE')
                p['version'] += 1
                event(p, 'error', code='MEDIA_PARSE_FAILED', content=f'第 {episode} 集素材解析未完成。')
            return True
        with self.store.transaction(pid) as p:
            next(a for a in p['attachments'] if a['id'] == attachment['id'])['text'] = text
            p['status'] = 'paused' if p['paused'] else 'ready'
            p['resume_status'] = 'ready'
            p['version'] += 1
        return True

    async def run_one(self, pid):
        if await self.prepare_transcription(pid):
            return True
        # Claim and reserve atomically. Network calls never hold a database lock.
        with self.store.transaction(pid) as p:
            if p['status'] != 'ready' or p['paused'] or any(c['status'] == 'pending' for c in p.get('conflicts', [])):
                return False
            expand_analysis(p)
            payload = self.payload(p)
            # Binary video/image understanding must be supplied by the original adapter.
            if any(not a.get('text') for a in payload['sources']):
                p['status'] = 'failed'
                event(p, 'error', code='MEDIA_ADAPTER_REQUIRED', content='素材需接入原有视频或图片解析接口。')
                return True
            try:
                reserve = self.provider.reserve(payload)
            except ProviderError as exc:
                p['status'] = 'failed'
                code = 'CONTEXT_LIMIT' if str(exc) == 'CONTEXT_LIMIT' else 'SERVICE_NOT_CONFIGURED'
                content = '本阶段上下文超过配置容量，材料已完整保存，请调整分批或容量配置。' if code == 'CONTEXT_LIMIT' else '生成服务尚未配置。'
                event(p, 'error', code=code, content=content)
                return True
            if p['budget']['spent'] + p['budget']['reserved'] + reserve > p['budget']['cap']:
                p['status'] = 'failed'
                event(p, 'error', code='BUDGET_LIMIT', content='剩余额度不足，请核对预算。')
                return True
            p['budget']['reserved'] += reserve
            run = dict(id=uid(), stage=current(p)['key'], status='running', reserved=reserve,
                       requirement_version=len(p['requirements']), started_at=now())
            p['runs'].append(run)
            p['status'] = 'running'
            snapshot = copy.deepcopy(p)
            event(p, 'progress', stage=current(p)['title'], task_id=run['id'], eta_seconds=None)
        try:
            output, cost = await self.provider.generate(payload)
            self.validate(snapshot, output)
            if not math.isfinite(cost) or cost < 0:
                raise RuleError('INVALID_COST')
        except Exception as exc:
            with self.store.transaction(pid) as p:
                next(r for r in p['runs'] if r['id'] == run['id'])['status'] = 'uncertain'
                p['status'] = 'failed'
                if current(p)['key'].startswith('transcribe_'):
                    code = 'OUTPUT_TRUNCATED' if str(exc) == 'INCOMPLETE_OUTPUT' else 'INVALID_RECORD' if isinstance(exc, RuleError) else 'GENERATION_FAILED'
                    self.transcription_failed(p, current(p)['episode'], code)
                    p['version'] += 1
                # Keep reservation: a timed-out remote call may already have been charged.
                event(p, 'error', code='GENERATION_FAILED', content='本步未完成，已保留材料和费用预留，可核对后重试。')
            return True
        with self.store.transaction(pid) as p:
            p['budget']['reserved'] = max(0, p['budget']['reserved'] - reserve)
            p['budget']['spent'] += cost
            next(r for r in p['runs'] if r['id'] == run['id']).update(status='completed', cost=cost, finished_at=now())
            stage = current(p)
            previous = p['outputs'].get(stage['key'])
            if previous:
                p.setdefault('history', []).append(dict(stage=stage['key'], output=previous))
            p['outputs'][stage['key']] = output
            if p['kind'] != 'transcribe':
                for n, text in output.get('scripts', {}).items():
                    p['scripts'][n] = text
            if stage['key'].startswith('transcribe_'):
                episode = str(stage['episode'])
                p['scripts'][episode] = output['content']
                p.setdefault('transcribe_versions', {})[episode] = p['version'] + 1
                p.setdefault('transcribe_failures', {}).pop(episode, None)
                p.pop('transcribe_error', None)
            event(p, 'report', stage=stage['key'], content=output['content'])
            needs_review = (stage['gate'] and not (p['fast_forward'] and stage['key'].startswith('script_')))
            needs_review |= any(c['status'] == 'pending' for c in p.get('conflicts', []))
            needs_review |= bool(output.get('issues')) or len(p['requirements']) != run['requirement_version']
            needs_review |= p['revisions'].get(stage['key'], 0) >= 3
            if needs_review:
                if stage['key'].startswith('transcribe_'):
                    if episode not in p.setdefault('transcribe_unapproved', []):
                        p['transcribe_unapproved'].append(episode)
                p['status'] = 'waiting'
            elif stage['key'].startswith('transcribe_') and p.get('transcribe_queue') is not None:
                if episode in p.setdefault('transcribe_unapproved', []):
                    p['transcribe_unapproved'].remove(episode)
                self.advance_transcription(p)
            else:
                p['cursor'] += 1
                self.enter(p)
            p['version'] += 1
            if p['status'] == 'waiting':
                event(p, 'card', card=card(p))
            if p['paused']:
                p['resume_status'] = p['status']
                p['status'] = 'paused'
            event(p, 'state', status=p['status'], stage=current(p)['key'])
        return True

    def resolve_conflict(self, pid, conflict_id, choice):
        with self.store.transaction(pid) as p:
            conflict = next((c for c in p.get('conflicts', []) if c['id'] == conflict_id), None)
            if conflict is None:
                raise KeyError(conflict_id)
            if conflict['status'] == 'resolved':
                if conflict['choice'] != choice:
                    raise RuleError('CONFLICT_ALREADY_RESOLVED')
                return conflict
            old = next(r for r in p['requirements'] if r['id'] == conflict['old'])
            new = next(r for r in p['requirements'] if r['id'] == conflict['new'])
            if old['status'] != 'active':
                raise RuleError('CONFLICT_BASE_CHANGED')
            if choice == 'use_new':
                old['status'], new['status'] = 'superseded', 'active'
            elif choice == 'keep_old':
                new['status'] = 'rejected'
            else:
                raise RuleError('INVALID_CONFLICT_CHOICE', 422)
            conflict.update(status='resolved', choice=choice, resolved_at=now())
            p['version'] += 1
            reply(p, '已记录裁定，后续生成采用选定要求。')
            event(p, 'conflict_resolved', conflict=conflict)
            return conflict

    async def reply_one(self, pid):
        with self.store.transaction(pid) as p:
            item = next((i for i in p.get('inbox', []) if i['status'] == 'pending'), None)
            if item is None:
                return False
            item['status'] = 'running'
            message_id = item['id']
            snapshot = copy.deepcopy(p)
            intent = item['intent']
            run = None
            if intent['intent'] == 'conversation':
                payload = dict(stage={'key': 'conversation', 'title': '理解用户消息并回复'},
                    text=item['text'], card=card(p), status=p['status'],
                    requirements=p['requirements'], recent_messages=p['messages'][-12:])
                try:
                    reserve = self.provider.reserve(payload)
                    if p['budget']['spent'] + p['budget']['reserved'] + reserve > p['budget']['cap']:
                        raise ProviderError('BUDGET_LIMIT')
                except ProviderError:
                    item['status'] = 'blocked'
                    reply(p, '消息已保存。当前生成配置或额度不足，可使用当前卡片的明确选项，配置完成后重试该消息。')
                    return True
                p['budget']['reserved'] += reserve
                run = dict(id=uid(), stage='conversation', status='running', reserved=reserve,
                           started_at=now(), message_id=message_id)
                p['runs'].append(run)
        if run:
            try:
                result, cost = await self.provider.generate(payload)
                self.validate(snapshot, {**result, 'scripts': {}} , require_script=False)
                if not math.isfinite(cost) or cost < 0:
                    raise RuleError('INVALID_COST')
                intent = result
            except Exception:
                with self.store.transaction(pid) as p:
                    next(r for r in p['runs'] if r['id'] == run['id'])['status'] = 'uncertain'
                    next(i for i in p['inbox'] if i['id'] == message_id)['status'] = 'blocked'
                    reply(p, '本条消息暂未完成处理，原话已保存，可重试。')
                return True
            with self.store.transaction(pid) as p:
                p['budget']['reserved'] = max(0, p['budget']['reserved'] - reserve)
                p['budget']['spent'] += cost
                next(r for r in p['runs'] if r['id'] == run['id']).update(status='completed', cost=cost)
        if intent.get('intent') == 'action':
            allowed = {'confirm', 'revise', 'pause', 'resume', 'release_stops', 'retry'}
            try:
                if item['stage'] != current(snapshot)['key']:
                    raise RuleError('STALE_CARD')
                if intent.get('action') not in allowed or not isinstance(intent.get('answers', {}), dict):
                    raise RuleError('ACTION_NEEDS_CLARIFICATION')
                self.action(pid, item['version'], 'message-' + message_id,
                            intent['action'], intent.get('answers', {}))
                response = '已按你的指令处理，当前步骤已更新。'
            except RuleError as exc:
                response = '还需要核对当前卡片或补充必填项，请根据最新卡片确认。'
                with self.store.transaction(pid) as p:
                    event(p, 'action_needs_clarification', code=exc.code, message_id=message_id, card=card(p))
        else:
            response = intent.get('content', '请补充你希望调整的内容。')
        with self.store.transaction(pid) as p:
            if intent.get('intent') == 'requirement' and p['status'] != 'delivered':
                response = add_requirement(p, item['text'], intent.get('field'),
                                           intent.get('value'), intent.get('conflicts_with'))
            next(i for i in p['inbox'] if i['id'] == message_id)['status'] = 'completed'
            reply(p, response)
        return True

    def retry_message(self, pid, message_id):
        with self.store.transaction(pid) as p:
            item = next((i for i in p.get('inbox', []) if i['id'] == message_id), None)
            if item is None:
                raise KeyError(message_id)
            if item['status'] != 'blocked':
                raise RuleError('MESSAGE_NOT_BLOCKED')
            item['status'] = 'pending'
            item['version'] = p['version']

    def validate(self, p, output, require_script=True):
        if not isinstance(output, dict) or not isinstance(output.get('content'), str) or not output['content'].strip():
            raise RuleError('EMPTY_OUTPUT')
        if not isinstance(output.get('issues', []), list) or not isinstance(output.get('questions', []), list):
            raise RuleError('INVALID_OUTPUT')
        visible = json.dumps(output, ensure_ascii=False)
        if re.search(r'(?i)gpt[- ]\d|sk-[a-zA-Z0-9]{12,}|input_tokens|output_tokens|system prompt', visible):
            raise RuleError('INTERNAL_INFORMATION_IN_OUTPUT')
        scripts = output.get('scripts', {})
        if not isinstance(scripts, dict):
            raise RuleError('INVALID_SCRIPTS')
        for n, text in scripts.items():
            if p['total'] is None or n not in {str(i) for i in range(p['start'], p['total'] + 1)}:
                raise RuleError('LOCKED_OR_OUT_OF_RANGE')
            if not isinstance(text, str) or not text.strip():
                raise RuleError('EMPTY_SCRIPT')
        stage = current(p)
        if require_script and stage['key'].startswith('script_') and str(stage['episode']) not in scripts:
            raise RuleError('SCRIPT_MISSING')
        if not stage['key'].startswith(('script_', 'transcribe_')) and len(output['content']) > 50000:
            raise RuleError('OUTPUT_REQUIRES_SPLITTING')
