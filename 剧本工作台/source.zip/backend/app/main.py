import asyncio
import contextlib
import hashlib
import base64
import hmac
import json
import os
from contextlib import asynccontextmanager
from typing import Literal
from pathlib import Path
from fastapi import FastAPI, Depends, Header, Request, HTTPException
from fastapi.responses import JSONResponse, Response, StreamingResponse
from pydantic import BaseModel, Field, model_validator
from .storage import Store, uid, now, event
from .service import Service, RuleError, public, current
from .providers import GPTProvider, HTTPVideoAdapter
from .files import extract, export, word, MAX_BYTES


class ProjectInput(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    kind: Literal['foreign', 'domestic', 'original', 'transcribe']
    total: int = Field(ge=1, le=300)
    start: int = Field(default=1, ge=1)
    locked: dict[str, str] = Field(default_factory=dict)
    brief: str = Field(default='', max_length=100000)

    @model_validator(mode='after')
    def valid_range(self):
        if self.start > self.total or any(not value for value in self.locked.values()):
            raise ValueError('invalid episode range or locked text')
        return self


class MessageInput(BaseModel):
    client_id: str = Field(min_length=1, max_length=100)
    text: str = Field(min_length=1, max_length=100000)


class ActionInput(BaseModel):
    version: int = Field(ge=1)
    action_id: str = Field(min_length=1, max_length=100)
    action: Literal['confirm', 'revise', 'pause', 'resume', 'retry', 'release_stops']
    answers: dict = Field(default_factory=dict)


class BudgetInput(BaseModel):
    cap: float = Field(ge=0, le=10000, allow_inf_nan=False)


class AttachmentMetadata(BaseModel):
    role: Literal['source', 'reference', 'locked', 'setting'] = 'source'
    episode: int | None = Field(default=None, ge=1)


class ConflictInput(BaseModel):
    choice: Literal['keep_old', 'use_new']


class ReconcileInput(BaseModel):
    cost: float = Field(ge=0, allow_inf_nan=False)


class TransferInput(BaseModel):
    kind: Literal['foreign', 'domestic']
    title: str = Field(min_length=1, max_length=200)


def create_app(root=None, provider=None, run_worker=True, token=None, media_adapter=None):
    store = Store(root or os.getenv('DATA_DIR', './data'))
    service = Service(store, provider or GPTProvider())
    adapter = media_adapter or HTTPVideoAdapter()
    access_token = token if token is not None else os.getenv('APP_TOKEN', '')

    async def auth(authorization: str = Header(default='')):
        if not access_token:
            raise HTTPException(503, 'APP_AUTH_NOT_CONFIGURED')
        if not hmac.compare_digest(authorization, 'Bearer ' + access_token):
            raise HTTPException(401, 'UNAUTHORIZED')

    async def worker():
        while True:
            for project in store.all():
                if project['status'] == 'ready':
                    try:
                        await service.run_one(project['id'])
                    except Exception:
                        # Catch unexpected storage/transition errors without terminating the worker.
                        with store.transaction(project['id']) as p:
                            p['status'] = 'failed'
                            event(p, 'error', code='TASK_FAILED', content='任务中断，已保留进度。')
            await asyncio.sleep(0.2)

    async def conversation_worker():
        while True:
            for project in store.all():
                try:
                    await service.reply_one(project['id'])
                except Exception:
                    with store.transaction(project['id']) as p:
                        for item in p.get('inbox', []):
                            if item['status'] == 'running':
                                item['status'] = 'blocked'
                        event(p, 'error', code='MESSAGE_FAILED', content='消息处理中断，原话已保存。')
            await asyncio.sleep(0.2)

    @asynccontextmanager
    async def lifespan(app):
        # Single-process deployment. Recovery never silently repeats a potentially billed call.
        for project in store.all():
            if project['status'] == 'running':
                with store.transaction(project['id']) as p:
                    p['status'] = 'failed'
                    for run in p['runs']:
                        if run['status'] == 'running':
                            run['status'] = 'uncertain'
                    event(p, 'error', code='WORKER_INTERRUPTED', content='执行中断，请核对后重试。')
        for project in store.all():
            with store.transaction(project['id']) as p:
                for run in p['runs']:
                    if run['status'] == 'running':
                        run['status'] = 'uncertain'
                for item in p.get('inbox', []):
                    if item['status'] == 'running':
                        item['status'] = 'blocked'
        task = asyncio.create_task(worker()) if run_worker else None
        dialogue_task = asyncio.create_task(conversation_worker()) if run_worker else None
        yield
        if dialogue_task:
            dialogue_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await dialogue_task
        if task:
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task

    app = FastAPI(title='短剧工作流后端', version='0.2.0', lifespan=lifespan,
                  docs_url=None, redoc_url=None, openapi_url=None)
    app.state.service = service
    app.state.store = store

    @app.exception_handler(RuleError)
    async def business_error(request, exc):
        return JSONResponse({'error': {'code': exc.code}}, status_code=exc.status)

    @app.exception_handler(KeyError)
    async def missing(request, exc):
        return JSONResponse({'error': {'code': 'NOT_FOUND'}}, status_code=404)

    @app.get('/health')
    async def health():
        return {'status': 'ok'}

    @app.get('/api/schema', dependencies=[Depends(auth)])
    async def schema():
        return app.openapi()

    @app.post('/api/projects', dependencies=[Depends(auth)], status_code=201)
    def create(body: ProjectInput):
        return service.create(**body.model_dump())

    @app.get('/api/projects', dependencies=[Depends(auth)])
    def projects(q: str = ''):
        return [dict(id=p['id'], title=p['title'], kind=p['kind'], status=p['status'], updated_at=p['updated_at'])
                for p in sorted(store.all(), key=lambda p: p['updated_at'], reverse=True)
                if q.casefold() in p['title'].casefold()]

    @app.get('/api/projects/{pid}', dependencies=[Depends(auth)])
    def detail(pid: str):
        return public(store.get(pid))

    @app.post('/api/projects/{pid}/messages', dependencies=[Depends(auth)])
    def message(pid: str, body: MessageInput):
        return service.message(pid, **body.model_dump())

    @app.post('/api/projects/{pid}/messages/{message_id}/retry', dependencies=[Depends(auth)])
    def retry_message(pid: str, message_id: str):
        service.retry_message(pid, message_id)
        return {'status': 'pending'}

    @app.post('/api/projects/{pid}/conflicts/{conflict_id}', dependencies=[Depends(auth)])
    def conflict(pid: str, conflict_id: str, body: ConflictInput):
        return service.resolve_conflict(pid, conflict_id, body.choice)

    @app.get('/api/projects/{pid}/outputs/{stage}/export', dependencies=[Depends(auth)])
    def stage_export(pid: str, stage: str):
        p = store.get(pid)
        output = p['outputs'].get(stage)
        if output is None:
            raise KeyError(stage)
        if output.get('parts'):
            import io
            import zipfile
            buffer = io.BytesIO()
            with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as archive:
                for index, part in enumerate(output['parts'], 1):
                    archive.writestr(f'part-{index}.docx', word(p['title'], p['outputs'][part]['content']))
            return Response(buffer.getvalue(), media_type='application/zip',
                            headers={'Content-Disposition': 'attachment; filename="analysis.zip"'})
        return Response(word(p['title'], output['content']),
            media_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            headers={'Content-Disposition': 'attachment; filename="stage.docx"'})

    @app.post('/api/projects/{pid}/actions', dependencies=[Depends(auth)])
    def action(pid: str, body: ActionInput):
        return service.action(pid, **body.model_dump())

    @app.put('/api/projects/{pid}/budget', dependencies=[Depends(auth)])
    def budget(pid: str, body: BudgetInput):
        service.approve_budget(pid, body.cap)
        return public(store.get(pid))['budget']

    @app.post('/api/projects/{pid}/attachments', dependencies=[Depends(auth)], status_code=201)
    async def upload(pid: str, request: Request, name: str,
                     role: Literal['source', 'reference', 'locked', 'setting'] = 'source',
                     episode: int | None = None):
        store.get(pid)
        data = bytearray()
        async for chunk in request.stream():
            data.extend(chunk)
            if len(data) > MAX_BYTES:
                raise HTTPException(413, 'FILE_TOO_LARGE')
        if not data:
            raise HTTPException(422, 'EMPTY_FILE')
        try:
            text = await asyncio.to_thread(extract, name, bytes(data))
        except Exception:
            raise HTTPException(422, 'FILE_PARSE_FAILED')
        aid = uid()
        path = store.root / aid
        path.write_bytes(data)
        try:
            with store.transaction(pid) as p:
                if episode is not None and not 1 <= episode <= p['total']:
                    raise RuleError('EPISODE_OUT_OF_RANGE', 422)
                if p['status'] == 'delivered':
                    raise RuleError('PROJECT_LOCKED')
                attachment = dict(id=aid, name=Path(name).name, role=role, episode=episode,
                                  size=len(data), sha256=hashlib.sha256(data).hexdigest(), text=text)
                p['attachments'].append(attachment)
                event(p, 'attachment', attachment_id=aid, name=attachment['name'], needs_episode=p['kind'] == 'transcribe' and episode is None)
                if current(p)['key'] == 'recap':
                    p['version'] += 1
                    service.recap(p)
                else:
                    p['requirements'].append(dict(id=uid(), text='新增附件 ' + attachment['name'],
                        at=now(), stage=current(p)['key'], version=len(p['requirements']) + 1, status='active'))
        except Exception:
            path.unlink(missing_ok=True)
            raise
        return {'id': aid, 'name': attachment['name'], 'needs_episode': p['kind'] == 'transcribe' and episode is None}

    @app.patch('/api/projects/{pid}/attachments/{aid}', dependencies=[Depends(auth)])
    def metadata(pid: str, aid: str, body: AttachmentMetadata):
        with store.transaction(pid) as p:
            if current(p)['key'] != 'recap':
                raise RuleError('SOURCE_MAPPING_ALREADY_CONFIRMED')
            if body.episode and body.episode > p['total']:
                raise RuleError('EPISODE_OUT_OF_RANGE', 422)
            attachment = next((a for a in p['attachments'] if a['id'] == aid), None)
            if attachment is None:
                raise KeyError(aid)
            attachment.update(body.model_dump())
            p['version'] += 1
            service.recap(p)
        return {'id': aid, **body.model_dump()}

    @app.post('/api/projects/{pid}/attachments/{aid}/parse', dependencies=[Depends(auth)])
    async def parse_media(pid: str, aid: str):
        project = store.get(pid)
        attachment = next((a for a in project['attachments'] if a['id'] == aid), None)
        if attachment is None:
            raise KeyError(aid)
        if attachment.get('text'):
            return {'id': aid, 'status': 'parsed'}
        # The existing service must enforce its own approved media budget.
        # No automatic call until the user explicitly requests this operation.
        try:
            result = await adapter.execute('parse_media', {
                'project_id': pid, 'attachment_id': aid,
                'mode': project['decisions'].get('mode', {}).get('mode'),
                'name': attachment['name'],
                'data_base64': base64.b64encode((store.root / aid).read_bytes()).decode()})
            text = result['text']
            if not isinstance(text, str) or not text.strip():
                raise ValueError('empty media output')
        except Exception:
            raise HTTPException(503, 'MEDIA_ADAPTER_FAILED_OR_UNCONFIGURED')
        with store.transaction(pid) as p:
            if p['status'] == 'delivered':
                raise RuleError('PROJECT_LOCKED')
            target = next(a for a in p['attachments'] if a['id'] == aid)
            target['text'] = text
            event(p, 'report', content='素材解析完成，可继续当前流程。')
        return {'id': aid, 'status': 'parsed'}

    @app.post('/api/projects/{pid}/runs/{run_id}/reconcile', dependencies=[Depends(auth)])
    def reconcile(pid: str, run_id: str, body: ReconcileInput):
        with store.transaction(pid) as p:
            run = next((r for r in p['runs'] if r['id'] == run_id), None)
            if run is None:
                raise KeyError(run_id)
            if run['status'] == 'reconciled' and run['cost'] == body.cost:
                return {'status': 'reconciled'}
            if run['status'] != 'uncertain':
                raise RuleError('RUN_NOT_UNCERTAIN')
            p['budget']['reserved'] = max(0, p['budget']['reserved'] - run['reserved'])
            p['budget']['spent'] += body.cost
            run.update(status='reconciled', cost=body.cost)
            event(p, 'report', content='已按账单核对本次任务费用。')
        return {'status': 'reconciled'}

    @app.get('/api/projects/{pid}/runs', dependencies=[Depends(auth)])
    def runs(pid: str):
        return store.get(pid)['runs']

    @app.get('/api/projects/{pid}/versions', dependencies=[Depends(auth)])
    def versions(pid: str):
        return store.get(pid).get('history', [])

    @app.get('/api/projects/{pid}/events', dependencies=[Depends(auth)])
    async def events(pid: str, request: Request, after: int = 0,
                     last_event_id: str | None = Header(default=None)):
        store.get(pid)
        try:
            cursor = max(after, int(last_event_id or 0))
        except ValueError:
            raise HTTPException(422, 'INVALID_EVENT_CURSOR')
        async def stream():
            nonlocal cursor
            while not await request.is_disconnected():
                batch = [e for e in store.get(pid)['events'] if e['id'] > cursor]
                for item in batch:
                    cursor = item['id']
                    yield f"id: {cursor}\nevent: {item['type']}\ndata: {json.dumps(item, ensure_ascii=False)}\n\n"
                if not batch:
                    yield ': heartbeat\n\n'
                await asyncio.sleep(1)
        return StreamingResponse(stream(), media_type='text/event-stream',
                                 headers={'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no'})

    @app.get('/api/projects/{pid}/export', dependencies=[Depends(auth)])
    def download(pid: str):
        p = store.get(pid)
        if current(p)['key'] != 'delivery':
            raise RuleError('DELIVERY_NOT_READY')
        try:
            name, data = export(p)
        except ImportError:
            raise HTTPException(503, 'EXPORT_DEPENDENCY_MISSING')
        return Response(data, media_type='application/zip' if name.endswith('.zip') else
                        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                        headers={'Content-Disposition': f'attachment; filename="{name}"'})

    @app.post('/api/projects/{pid}/transfer', dependencies=[Depends(auth)], status_code=201)
    def transfer(pid: str, body: TransferInput):
        source = store.get(pid)
        if source['kind'] != 'transcribe' or current(source)['key'] != 'delivery':
            raise RuleError('TRANSCRIPTION_DELIVERY_REQUIRED')
        result = service.create(body.title, body.kind, source['total'], brief='根据已完成扒剧改编')
        with store.transaction(result['id']) as p:
            p['attachments'] = [dict(id=uid(), name='扒剧底稿.txt', role='source', episode=None,
                text='\n\n'.join(source['scripts'].values()), source_project=pid)]
            service.recap(p)
        return public(store.get(result['id']))

    return app


app = create_app()
