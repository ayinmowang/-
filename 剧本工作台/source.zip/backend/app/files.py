import io
import re
import zipfile
from pathlib import Path
from docx import Document
from openpyxl import load_workbook

MAX_BYTES = 50 * 1024 * 1024


def extract(name, data):
    suffix = Path(name).suffix.lower()
    if suffix in {'.txt', '.md'}:
        return data.decode('utf-8')
    if suffix in {'.docx', '.xlsx', '.zip'}:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            entries = archive.infolist()
            if len(entries) > 3000 or sum(f.file_size for f in entries) > MAX_BYTES:
                raise ValueError('ARCHIVE_TOO_LARGE')
        if suffix == '.docx':
            doc = Document(io.BytesIO(data))
            paragraphs = [p.text for p in doc.paragraphs]
            paragraphs += ['\t'.join(c.text for c in row.cells) for t in doc.tables for row in t.rows]
            return '\n'.join(paragraphs)
        if suffix == '.xlsx':
            workbook = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
            try:
                return '\n'.join('\t'.join('' if v is None else str(v) for v in row)
                                 for sheet in workbook for row in sheet.values)
            finally:
                workbook.close()
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            texts = []
            for item in archive.infolist():
                if Path(item.filename).suffix.lower() in {'.txt', '.md', '.docx', '.xlsx'}:
                    texts.append(item.filename + '\n' + extract(item.filename, archive.read(item)))
            return '\n\n'.join(texts)
    if suffix in {'.mp4', '.png', '.jpg', '.jpeg', '.webp'}:
        return ''
    raise ValueError('UNSUPPORTED_FILE')


def split_locked(name, text, count):
    """Preserve every character, including heading lines and leading material."""
    if not text.strip():
        raise ValueError('empty locked manuscript')
    headings = list(re.finditer(r'(?m)^\s*?第[ \t]*(\d{1,3})[ \t]*集(?:[ \t：:、].*)?\r?$', text))
    if not headings:
        named = re.search(r'第\s*(\d{1,3})\s*集', Path(name).stem)
        numeric = re.fullmatch(r'(?:ep)?0*(\d{1,3})', Path(name).stem, re.I)
        episode = int((named or numeric).group(1)) if named or numeric else (1 if count == 1 else 0)
        if not 1 <= episode <= count:
            raise ValueError('episode missing or out of range')
        return {str(episode): text}
    parts = {}
    for i, heading in enumerate(headings):
        episode = str(int(heading[1]))
        if not 1 <= int(episode) <= count or episode in parts:
            raise ValueError('duplicate or out of range')
        end = headings[i + 1].start() if i + 1 < len(headings) else len(text)
        parts[episode] = text[heading.start() if i else 0:end]
    return parts


def word(title, text):
    doc = Document()
    doc.add_heading(title, 0)
    for line in text.split('\n'):
        doc.add_paragraph(line)
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def export(project):
    synopsis = project['outputs'].get('synopsis', {}).get('content', '')
    chapters = {**project['locked'], **project['scripts']}
    text = synopsis + '\n\n正文\n' + '\n\n'.join(
        f'第 {n} 集\n{chapters[str(n)]}' for n in range(1, project['total'] + 1))
    if project['kind'] != 'transcribe':
        return 'screenplay.docx', word(project['title'], text)
    from opencc import OpenCC
    traditional = OpenCC('s2t')
    simplified = OpenCC('t2s')
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('全集简体.docx', word(project['title'], simplified.convert(text)))
        for n, content in sorted(chapters.items(), key=lambda item: int(item[0])):
            archive.writestr(f'第{n}集繁体.docx', word(f'第 {n} 集', traditional.convert(content)))
    return 'screenplay.zip', buf.getvalue()
