import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from uuid import uuid4
from datetime import datetime, timezone


def uid():
    return uuid4().hex


def now():
    return datetime.now(timezone.utc).isoformat()


def event(project, kind, **payload):
    item = dict(id=len(project['events']) + 1, type=kind, at=now(), **payload)
    project['events'].append(item)
    project['updated_at'] = item['at']
    return item


class Store:
    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.db = self.root / 'drama.sqlite3'
        with self.connect() as con:
            con.execute('PRAGMA journal_mode=WAL')
            con.execute('CREATE TABLE IF NOT EXISTS projects (id TEXT PRIMARY KEY, body TEXT NOT NULL)')

    def connect(self):
        return sqlite3.connect(self.db, timeout=30)

    @contextmanager
    def transaction(self, project_id):
        with self.connect() as con:
            con.execute('BEGIN IMMEDIATE')
            row = con.execute('SELECT body FROM projects WHERE id=?', (project_id,)).fetchone()
            if row is None:
                raise KeyError(project_id)
            project = json.loads(row[0])
            yield project
            con.execute('UPDATE projects SET body=? WHERE id=?',
                        (json.dumps(project, ensure_ascii=False), project_id))

    def create(self, project):
        with self.connect() as con:
            con.execute('INSERT INTO projects VALUES (?, ?)',
                        (project['id'], json.dumps(project, ensure_ascii=False)))

    def get(self, project_id):
        with self.connect() as con:
            row = con.execute('SELECT body FROM projects WHERE id=?', (project_id,)).fetchone()
        if row is None:
            raise KeyError(project_id)
        return json.loads(row[0])

    def all(self):
        with self.connect() as con:
            return [json.loads(row[0]) for row in con.execute('SELECT body FROM projects')]
