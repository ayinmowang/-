# AI 短剧网站后端 v0.2.0

可运行的后端第二版，Python 3.11+、FastAPI、SQLite。仓库根目录的聊天工作台通过本服务运行正式创作流程。四种流程、任务状态、要求台账、停点确认、文件导出均通过 HTTP API 使用。

## 启动

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
# 在运行环境设置 .env.example 中的变量。本项目不自动读取 .env。
uvicorn app.main:app --host 127.0.0.1 --port 8000 --workers 1
```

必须设置 `APP_TOKEN`。业务接口使用 `Authorization: Bearer <APP_TOKEN>`。这是 ayin 单用户内部服务，所有持有该令牌的客户端拥有同一工作区权限。接入现有登录系统时应把 `auth` 替换为真实用户身份并给项目增加 owner 过滤。当前版本限定单进程 worker，数据库和文件保存在 `DATA_DIR`，请持久化该目录。

GPT 配置使用 `OPENAI_API_KEY`、`OPENAI_MODEL`、`OPENAI_BASE_URL`。`INPUT_USD_PER_MILLION` 与 `OUTPUT_USD_PER_MILLION` 必须填写所选 GPT 模型当前价格，单位美元/百万 tokens。未配置时任务明确失败，始终保留用户材料。API Key 仅由后端读取。模型使用 OpenAI Responses API，模型名称由部署者配置。

健康检查为 `/health`，授权后的 OpenAPI 契约为 `/api/schema`。根路径没有页面。

## 使用顺序

1. `POST /api/projects` 建立项目，提交 `title`、`kind`、`total`、`start`、`locked`、`brief`。kind 为 foreign / domestic / original / transcribe。续写的 locked 是集号到原文的映射，必须完整覆盖 1 到 start-1。
2. 需要原稿时用 `POST /api/projects/{id}/attachments?name=source.docx&role=source` 上传原始文件字节。支持 DOCX、XLSX、TXT、MD、ZIP、MP4 和图片。单文件 50 MB 上限。视频与图片收件后需原有媒体解析接口处理。扒剧为每集指定 episode，无法识别时使用附件 PATCH 接口补录。
3. 读取项目，核对 recap 卡片。上传后 recap 自动刷新，不等待模型。普通对话用 `POST .../messages`，提交唯一 client_id 和 text。
4. 通过 `PUT .../budget` 设置本项目已批准的美元 cap。开发用额度由操作者填写，不会自动启用计划书中的上限。
5. 提交 `POST .../actions`，包含当前 version、唯一 action_id、action 和 answers。confirm 确认卡片并启动下一步。后台自动执行没有停点的阶段。有卡片时填写全部 fields；questions 非空还需 answers.decisions；issues 非空还需 answers.resolution。复核问题也可选择 revise。
6. 通过项目查询或 SSE 查看进度。SSE 路径 `/api/projects/{id}/events`，支持 `Last-Event-ID` 或 after 参数，需携带 Authorization。
7. 到 delivery 时通过 `/api/projects/{id}/export` 下载 Word 或 ZIP，确认 delivery 后项目锁定。交付前若需重写某集，用 revise，并提交 feedback 和 episode。

示例请求体：

```json
{
  "title": "原创测试剧",
  "kind": "original",
  "total": 3,
  "start": 1,
  "locked": {},
  "brief": "演员拿错剧本后发现一场真实阴谋"
}
```

```json
{
  "version": 1,
  "action_id": "client-operation-001",
  "action": "confirm",
  "answers": {}
}
```

同一 action_id 重放返回第一次结果，相同标识换请求体会拒绝。过期 version 返回 STALE_CARD。messages 的 client_id 同样去重。pause/resume/retry/release_stops 均通过 actions 提交。release_stops 仅放开当前正文阶段后续逐集停点，质量问题仍停下。暂停不强行取消已发出的模型请求，当前结果保存后暂停。

## 四条流程

- 国外迭代：复述 → 分析及待定项 → 四项配置 → 主线方案 → 看得懂关 → 梗概人物剧名 → 首批细纲 → 全剧细纲 → 正文前三集逐集 → 自动审改 → 交付。
- 国内迭代：在分析后增加四级诊断及世界观、人设、替换要点三道门，审改增加北美语感和美式幽默精修。
- 原创：复述 → 前四层推理及停点 A → 设定集 → 每十集细纲确认 → 全部细纲确认 → 正文前三集逐集 → 审改 → 交付。
- 扒剧：素材映射 → 无默认的 fast/detailed 选择 → 逐集处理 → 梗概人物 → 交付。仅显式调用 transfer 才创建迭代项目。ZIP 包含繁体单集与简体全集 Word。

暂按计划书建议实现“国内三门紧接分析”和“续写本轮前三个待写集逐集停”，规则位于 `app/workflows.py`，可在拍板后调整。原创可暂缓总集数，待停点 A 确认后生成细纲与正文计划。迭代和扒剧建档时确定总集数与范围。

## 原有 API 接口位

`app/providers.py` 的 `LegacyAdapter.execute(operation, payload)` 为原有后端接入点。原接口路径、认证和返回值尚未提供，因此不会假设原站已经接通。

媒体桥接实现为 `HTTPVideoAdapter`，读取 `LEGACY_API_BASE_URL`、`LEGACY_API_TOKEN`。显式调用附件 `/parse` 时请求桥接服务 `POST /v1/execute`，传入 operation=parse_media、project_id、attachment_id、name、mode 和 data_base64。返回 `{ "text": "完整解析材料" }`。已有 API 若格式不同，在该适配器内转换。请使用项目和附件标识在原服务去重，并由原媒体服务执行其费用授权与封顶。原服务成本尚未计入本地 GPT 账本。

迭代、审稿或导出如需沿用原能力，可用相同接口模式增加 operation。当前文本创作由 GPTProvider 完成，Word 导出在本地完成。没有解析结果的二进制素材不会被当作“已观看视频”交给 GPT。

## 费用与恢复

每次 GPT 调用前按 UTF-8 输入字节保守估计输入上界，加系统指令开销，再按最大输出预留。预算不足时停止派发。成功后按服务返回的用量及配置价格结算。超时、无效输出和进程中断保留预留金额，避免未知账单被漏算。

`GET .../runs` 查任务；核对实际账单后 `POST .../runs/{run_id}/reconcile`，提交 `{ "cost": 0.01 }` 结算未知任务。相同结算重放不会重复扣账。然后选择 retry。内部用量不通过用户消息暴露。

## 测试

```bash
python3 -m unittest discover -s tests -v
```

业务回归使用明确标识的确定性测试替身，验证状态机、并发和交付一致性。

配置真实 GPT 凭据、模型和价格后运行：

```bash
RUN_GPT_TESTS=1 GPT_TEST_BUDGET_USD=0.10 python3 -m unittest discover -s tests -p test_gpt_live.py -v
```

该测试从创建原创项目、批准测试额度、确认复述到 GPT 实际生成停点 A，全程走业务服务。只有配置环境变量后才会调用付费模型。预算不够时测试会失败，操作者可按所选模型调整批准额度。

## 本版边界与后续接入

这是可运行后端首版。缺少原网站源码，因此未迁移旧数据库、旧路由或原登录系统。实际 GPT 内容质量及完整长剧生成尚需真实凭据验证。

普通文字支持进度问答、明确控制指令、原话要求收集和 GPT 意图解析。复杂答卡由 GPT 提取字段，再经当前卡片版本和必填项校验执行。跨项目自动分流仍待接入。视频逐帧查看依赖原有媒体能力。当前上传为整文件，分片续传尚未实现。原稿分析按 SOURCE_BATCH_CHARS 分批，每批独立结算与保存，汇总保留完整分批内容及待定事项。原稿分析之外的阶段仍需将相关上下文整体传入，超出 MAX_INPUT_BYTES 时明确停下，跨阶段检索压缩尚待实现。阶段 Word 下载已提供，分批分析导出 ZIP，最终交付支持 Word/ZIP。

自动审改链已编排，三轮修改会停下等确认，尚未实现基于审稿规则的自动多轮返修与同类模型切换。历史版本保存在 versions 接口，第三期选句批注、版本差异和整批编辑尚未实现。

模型输出采用结构校验和基础内部信息检查，上线前仍须扩展全量敏感信息扫描。此版本适合本地联调，完成上述接口接入及生产验收后再上线。


## v0.2 新增接口与行为

- 明确的“通过”“暂停”“恢复”“重试”“写完吧”“快速模式”“详细模式”入持久化消息队列，独立对话 worker 执行。文本提交立即返回，模型请求不占用数据库事务。普通提问不再默认变成创作要求。
- GPT 可将复杂表达解析为 action、requirement 或 conversation。模型仅提取意图，状态机验证阶段版本、锁定规则、必填项和审批条件。旧卡消息不会推进新阶段。
- “背景：美国都市”等明确字段要求会检查同字段已有值。冲突保留新旧原话，暂停新增生成；在途结果保存后等确认。GPT 也可引用真实 requirement id 报告语义冲突。识别效果尚需真实 GPT 验证。
- `POST /api/projects/{id}/conflicts/{conflict_id}`，提交 `choice=keep_old` 或 `choice=use_new`。裁定幂等，后续生成仅注入 active 要求。
- `POST /api/projects/{id}/messages/{message_id}/retry` 重试缺额度、配置或调用失败的消息。对话成本计入同一项目预算，按各自 run id 结算，支持与创作任务并行。
- `GET /api/projects/{id}/outputs/{stage}/export` 下载阶段 Word。合并分析阶段返回各批 Word 的 ZIP，避免把多个批次缩写成一个摘要。
- `SOURCE_BATCH_CHARS` 默认 12000，按原文容量装箱，允许跨文件拼批。片段保留附件标识和起止偏移，可重建原文。每批是独立任务，失败重试不重跑之前完成的批次。`MAX_INPUT_BYTES` 默认 180000，为单次输入的保守容量边界，需要按所选 GPT 调整。

本次验证包括完整四类流程、并发费用结算、卡片过期、消息重放、冲突裁定、45 集材料按容量拼批及阶段导出。模型测试替身只验证契约与工作流。真实 GPT 测试仍需环境中的凭据。

## 单集提取与整批逐集交付

新客户端建档时可设置 `transcribe_scope_choice: true`；旧项目也可以在确认模式时传 `answers.choose_scope: true`。模式确认后，项目等候用户选择任务范围。使用现有 actions 接口提交 `extract_episode`（`answers.episode` 为已映射的集号）或 `extract_all_episodes`。整批按集号每三集一组、逐集运行并发布。某集输出无效时可单集重试。请通过项目快照的 `transcribeFailures` 和 `episodeDeliveries` 查看失败与交付。

`GET /api/projects/{id}/episodes/{episode}/export` 下载已经交付的繁体单集 Word，仍需工作区鉴权。整剧 ZIP 仍由现有 export 接口提供。已经交付的正文可在后续集仍在跑时下载。

视频任务由后台按集调用现有 `parse_media` 桥接服务，并传入明确选择的模式及集号。详细模式依赖桥接服务提供来自原始画面与声音的逐秒证据。服务端无法读到有效记录时会报告失败状态，不生成该集交付。文本生成继续走已有预算审批，媒体服务的费用仍由桥接侧管控。
