"""Use the website's actual request builder with the HTTP API."""
import asyncio
import io
import json
import subprocess
import tempfile
import unittest
from pathlib import Path

from docx import Document
from fastapi.testclient import TestClient
from app.main import create_app
from test_backend import TestProvider

ROOT = Path(__file__).resolve().parents[2]


class WebContract(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.app = create_app(self.tmp.name, TestProvider(), run_worker=False, token='test')
        self.client = TestClient(self.app, headers={'Authorization':'Bearer test'})
        self.addCleanup(self.client.close)

    def create(self, project, parts):
        js = """import {creationRequest} from './lib/intake.ts';
        const [project,parts] = JSON.parse(process.argv[1]);
        console.log(JSON.stringify(await creationRequest(project,async file=>parts[file.name])));"""
        result = subprocess.run(['node','--experimental-strip-types','--input-type=module','-e',js,
            json.dumps([project,parts])],cwd=ROOT,check=True,capture_output=True,text=True)
        response = self.client.post('/api/projects',json=json.loads(result.stdout))
        self.assertEqual(response.status_code,201,response.text)
        return response.json()['id']

    def action(self,pid,answers, action='confirm'):
        state = self.client.get('/api/projects/'+pid).json()
        return self.client.post('/api/projects/'+pid+'/actions',json=dict(action=action,
            action_id=f"{state['version']}-{action}",version=state['version'],answers=answers))

    def test_continuation_preserves_original(self):
        raw = '原封面\n第1集\n  留白  \n第2集\n这句不能动。\n'
        parsed = self.client.post('/api/locked-script',params={'name':'定稿.txt','count':2},content=raw.encode())
        self.assertEqual(parsed.status_code,200)
        self.assertEqual(''.join(parsed.json().values()), raw)
        pid=self.create(dict(kind='foreign',title='测试',total=3,brief='续写',lockedEpisodes=2,
            attachments=[dict(name='定稿.txt',role='locked')]),{'定稿.txt':parsed.json()})
        self.client.post(f'/api/projects/{pid}/attachments',params={'name':'source.txt'},content=b'source')
        self.client.put(f'/api/projects/{pid}/budget',json={'cap':2})
        for _ in range(80):
            p=self.client.get('/api/projects/'+pid).json()
            if p['stage']['key']=='delivery': break
            if p['status']=='waiting':
                answers={field:True for field in p['card']['fields']}
                self.assertEqual(self.action(pid,answers).status_code,200)
            else:
                self.assertEqual(p['status'],'ready')
                asyncio.run(self.app.state.service.run_one(pid))
        response=self.client.get(f'/api/projects/{pid}/export')
        self.assertEqual(response.status_code,200,response.text[:150] if response.status_code!=200 else '')
        paragraphs='\n'.join(i.text for i in Document(io.BytesIO(response.content)).paragraphs)
        for exact in parsed.json().values(): self.assertIn(exact, paragraphs)
        self.assertEqual(set(self.client.get('/api/projects/'+pid).json()['scripts']),{'3'})

    def test_deferred_total_budget_and_retry(self):
        pid=self.create(dict(kind='original',title='测试',total=None,brief='一个脑洞',attachments=[]),{})
        self.assertEqual(self.action(pid,{}).status_code,200)
        asyncio.run(self.app.state.service.run_one(pid))
        row=self.client.get('/api/admin/operations').json()[0]
        self.assertEqual(row['status'],'failed')
        self.assertEqual(row['budget']['cap'],0)
        self.assertEqual(self.client.put(f'/api/projects/{pid}/budget',json={'cap':1}).status_code,200)
        self.assertEqual(self.action(pid,{},'retry').status_code,200)
        asyncio.run(self.app.state.service.run_one(pid))
        answers=dict(direction='悬疑',opening='B',engine='误会',audience='女频',total='301')
        self.assertEqual(self.action(pid,answers).status_code,422)
        answers['total']='12'
        res=self.action(pid,answers)
        self.assertEqual(res.status_code,200,res.text)
        self.assertEqual(res.json()['total'],12)
        p=self.app.state.store.get(pid)
        self.assertIn('outline_11',[s['key'] for s in p['steps']])
        self.assertEqual(self.client.get('/api/admin/operations').json()[0]['retries'],1)
