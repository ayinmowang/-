"""Real GPT test. Opt in explicitly; never substitutes a fixture for GPT."""
import asyncio
import os
import tempfile
import unittest
from app.main import create_app
from app.providers import GPTProvider
from app.service import current


@unittest.skipUnless(os.getenv('RUN_GPT_TESTS') == '1', '需配置 GPT 凭据并设置 RUN_GPT_TESTS=1')
class GPTLiveTests(unittest.TestCase):
    def test_real_generation_from_project_entry(self):
        with tempfile.TemporaryDirectory() as root:
            app = create_app(root, GPTProvider(), run_worker=False, token='local-test')
            service = app.state.service
            p = service.create('原创 GPT 冒烟测试', 'original', 1, brief='一名演员误拿剧本，在试镜中发现真相。')
            service.approve_budget(p['id'], float(os.getenv('GPT_TEST_BUDGET_USD', '0.10')))
            service.action(p['id'], p['version'], 'begin', 'confirm', {})
            asyncio.run(service.run_one(p['id']))
            result = app.state.store.get(p['id'])
            self.assertEqual(result['status'], 'waiting', str(result['events'][-1]))
            self.assertEqual(current(result)['key'], 'reasoning')
            self.assertTrue(result['outputs']['reasoning']['content'].strip())
            self.assertGreater(result['budget']['spent'], 0)
