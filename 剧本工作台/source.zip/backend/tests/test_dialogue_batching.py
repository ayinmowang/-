import asyncio
import io
import tempfile
import unittest
import zipfile
from unittest.mock import patch
from fastapi.testclient import TestClient
from app.main import create_app
from app.batching import source_batches
from app.service import current
from test_backend import TestProvider


class DialogueBatchingTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.app = create_app(self.tmp.name, TestProvider(), run_worker=False, token='test')
        self.service = self.app.state.service
        self.store = self.app.state.store
        self.client = TestClient(self.app, headers={'Authorization': 'Bearer test'})
        self.pid = self.service.create('合成剧', 'original', 1, brief='脑洞')['id']
        self.service.approve_budget(self.pid, 10)

    def tearDown(self):
        self.client.close()
        self.tmp.cleanup()

    def message(self, text, key):
        return self.service.message(self.pid, key, text)

    def test_confirm_message_and_duplicate(self):
        self.message('通过', 'a')
        asyncio.run(self.service.reply_one(self.pid))
        self.message('通过', 'a')
        self.assertFalse(asyncio.run(self.service.reply_one(self.pid)))
        self.assertEqual(current(self.store.get(self.pid))['key'], 'reasoning')

    def test_stale_queued_confirm_cannot_advance_new_gate(self):
        self.message('通过', 'a')
        self.service.action(self.pid, 1, 'another-tab', 'confirm', {})
        asyncio.run(self.service.run_one(self.pid))
        asyncio.run(self.service.reply_one(self.pid))
        p = self.store.get(self.pid)
        self.assertEqual(current(p)['key'], 'reasoning')
        self.assertTrue(any(e.get('code') == 'STALE_CARD' for e in p['events']))

    def test_question_not_added_as_requirement(self):
        self.message('你推荐什么样的开场？', 'q')
        asyncio.run(self.service.reply_one(self.pid))
        p = self.store.get(self.pid)
        self.assertEqual(p['requirements'], [])
        self.assertEqual(p['cursor'], 0)
        self.assertEqual(p['inbox'][0]['status'], 'completed')

    def test_semantic_gpt_answer_obeys_required_fields(self):
        class Interpreter(TestProvider):
            async def generate(self, payload):
                return {'content': '你希望开始。', 'intent': 'action', 'action': 'confirm', 'answers': {}}, 0.001
        self.service.provider = Interpreter()
        self.message('复述准确，请进入下一步。', 'a')
        asyncio.run(self.service.reply_one(self.pid))
        self.assertEqual(self.store.get(self.pid)['status'], 'ready')

    def test_conflict_freezes_and_resolution_injects_only_active(self):
        self.message('背景：美国都市', 'a')
        self.message('背景：法国校园', 'b')
        p = self.store.get(self.pid)
        self.assertEqual(len(p['conflicts']), 1)
        r = self.client.post(f'/api/projects/{self.pid}/actions', json={
            'version': p['version'], 'action_id': 'start', 'action': 'confirm', 'answers': {}})
        self.assertEqual(r.status_code, 409)
        conflict_id = p['conflicts'][0]['id']
        for _ in range(2):
            self.assertEqual(self.client.post(f'/api/projects/{self.pid}/conflicts/{conflict_id}',
                json={'choice': 'use_new'}).status_code, 200)
        p = self.store.get(self.pid)
        requirements = self.service.payload(p)['requirements']
        self.assertEqual([r['text'] for r in requirements], ['背景：法国校园'])

    def test_dialogue_missing_budget_can_retry(self):
        self.service.approve_budget(self.pid, 0)
        msg = self.message('说说这个脑洞的优势？', 'a')
        asyncio.run(self.service.reply_one(self.pid))
        self.assertEqual(self.store.get(self.pid)['inbox'][0]['status'], 'blocked')
        self.service.approve_budget(self.pid, 1)
        self.service.retry_message(self.pid, msg['id'])
        asyncio.run(self.service.reply_one(self.pid))
        self.assertEqual(self.store.get(self.pid)['inbox'][0]['status'], 'completed')

    def test_capacity_packing_is_lossless_and_not_per_episode(self):
        materials = [dict(id=str(i), name=f'{i}.txt', role='source', text='第%d集。' % i) for i in range(45)]
        batches = source_batches(materials, capacity=100)
        self.assertLess(len(batches), 10)
        for material in materials:
            rebuilt = ''.join(part['text'] for batch in batches for part in batch if part['attachment_id'] == material['id'])
            self.assertEqual(rebuilt, material['text'])

    def test_analysis_batches_have_checkpoints_and_word_exports(self):
        pid = self.service.create('长原稿', 'foreign', 1)['id']
        self.service.approve_budget(pid, 10)
        self.client.post(f'/api/projects/{pid}/attachments', params={'name': 'source.txt'},
                         content=('长原稿。' * 700).encode())
        p = self.store.get(pid)
        self.service.action(pid, p['version'], 'start', 'confirm', {})
        with patch.dict('os.environ', {'SOURCE_BATCH_CHARS': '1000'}):
            asyncio.run(self.service.run_one(pid))
            first = self.store.get(pid)
            self.assertIn('analysis_part_1', first['outputs'])
            self.assertEqual(first['status'], 'ready')
            while self.store.get(pid)['status'] == 'ready':
                asyncio.run(self.service.run_one(pid))
        p = self.store.get(pid)
        self.assertEqual(current(p)['key'], 'analysis')
        self.assertEqual(p['status'], 'waiting')
        self.assertEqual(len(p['runs']), 3)
        r = self.client.get(f'/api/projects/{pid}/outputs/analysis/export')
        self.assertEqual(r.status_code, 200)
        with zipfile.ZipFile(io.BytesIO(r.content)) as archive:
            self.assertEqual(len(archive.namelist()), 3)

    def test_failed_analysis_batch_retry_preserves_completed_batch(self):
        calls = []
        class FailSecondBatch(TestProvider):
            async def generate(self, payload):
                key = payload['stage']['key']
                calls.append(key)
                if key == 'analysis_part_2' and calls.count(key) == 1:
                    raise TimeoutError()
                return await super().generate(payload)
        self.service.provider = FailSecondBatch()
        pid = self.service.create('失败恢复', 'foreign', 1)['id']
        self.service.approve_budget(pid, 10)
        self.client.post(f'/api/projects/{pid}/attachments', params={'name': 'source.txt'}, content=('甲' * 2500).encode())
        p = self.store.get(pid)
        self.service.action(pid, p['version'], 'start', 'confirm', {})
        with patch.dict('os.environ', {'SOURCE_BATCH_CHARS': '1000'}):
            asyncio.run(self.service.run_one(pid))
            asyncio.run(self.service.run_one(pid))
            p = self.store.get(pid)
            self.assertEqual(p['status'], 'failed')
            self.service.action(pid, p['version'], 'retry', 'retry', {})
            asyncio.run(self.service.run_one(pid))
            asyncio.run(self.service.run_one(pid))
        self.assertEqual(calls.count('analysis_part_1'), 1)
        self.assertEqual(calls.count('analysis_part_2'), 2)
        self.assertEqual(current(self.store.get(pid))['key'], 'analysis')

    def test_chat_and_generation_reservations_settle_their_own_runs(self):
        owner = self
        class ConcurrentProvider(TestProvider):
            async def generate(self, payload):
                if payload['stage']['key'] != 'conversation':
                    owner.message('有没有建议？', 'parallel')
                    await owner.service.reply_one(owner.pid)
                return await super().generate(payload)
        self.service.provider = ConcurrentProvider()
        self.service.action(self.pid, 1, 'start', 'confirm', {})
        asyncio.run(self.service.run_one(self.pid))
        p = self.store.get(self.pid)
        self.assertEqual([r['status'] for r in p['runs']], ['completed', 'completed'])
        self.assertAlmostEqual(p['budget']['spent'], 0.01)
        self.assertAlmostEqual(p['budget']['reserved'], 0)


if __name__ == '__main__':
    unittest.main()
