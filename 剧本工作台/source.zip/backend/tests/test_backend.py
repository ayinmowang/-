import asyncio
import io
import tempfile
import unittest
import zipfile
from concurrent.futures import ThreadPoolExecutor
from docx import Document
from fastapi.testclient import TestClient
from app.main import create_app
from app.service import current


class TestProvider:
    """Deterministic regression fixture, never described as a GPT response."""
    def reserve(self, payload):
        return 0.01

    async def generate(self, payload):
        stage = payload['stage']
        scripts = {}
        if stage['key'].startswith('script_'):
            scripts[str(stage['episode'])] = f"第{stage['episode']}集\n人物：按计划行动。"
        return {'content': stage['title'] + '\n梗概\n人物小传\n内容', 'scripts': scripts,
                'issues': [], 'questions': [], 'understandable': True}, 0.005


class BackendTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.app = create_app(self.tmp.name, TestProvider(), run_worker=False, token='test-only')
        self.client = TestClient(self.app, headers={'Authorization': 'Bearer test-only'})
        self.service = self.app.state.service
        self.store = self.app.state.store

    def tearDown(self):
        self.client.close()
        self.tmp.cleanup()

    def create(self, kind='original', total=3, start=1, locked=None):
        response = self.client.post('/api/projects', json=dict(title='合成测试剧', kind=kind,
            total=total, start=start, locked=locked or {}, brief='失业青年误入剧组'))
        self.assertEqual(response.status_code, 201, response.text)
        pid = response.json()['id']
        self.client.put(f'/api/projects/{pid}/budget', json={'cap': 3})
        if kind != 'original':
            for n in range(start, total + 1):
                r = self.client.post(f'/api/projects/{pid}/attachments',
                    params={'name': f'{n}.txt', 'episode': n}, content=f'第{n}集原文'.encode())
                self.assertEqual(r.status_code, 201, r.text)
        return pid

    def act(self, pid, action='confirm', answers=None, action_id=None):
        p = self.store.get(pid)
        if answers is None:
            answers = {f: '确认' for f in current(p)['fields']}
            answers.update(mode='fast', total=p['total'], understood=True)
        return self.client.post(f'/api/projects/{pid}/actions', json=dict(
            version=p['version'], action_id=action_id or f"{p['version']}-{action}",
            action=action, answers=answers))

    def finish(self, pid):
        visited = []
        for _ in range(150):
            p = self.store.get(pid)
            visited.append(current(p)['key'])
            if p['status'] == 'delivered':
                return visited
            if p['status'] == 'waiting':
                r = self.act(pid)
                self.assertEqual(r.status_code, 200, r.text)
            elif p['status'] == 'ready':
                asyncio.run(self.service.run_one(pid))
            else:
                self.fail(str(p['events'][-1]))
        self.fail('workflow did not terminate')

    def test_all_four_workflows(self):
        for kind in ['foreign', 'domestic', 'original', 'transcribe']:
            with self.subTest(kind=kind):
                pid = self.create(kind)
                visited = self.finish(pid)
                self.assertEqual(set(self.store.get(pid)['scripts']), {'1', '2', '3'})
                download = self.client.get(f'/api/projects/{pid}/export')
                self.assertEqual(download.status_code, 200, download.text[:100] if download.status_code != 200 else '')
                if kind == 'transcribe':
                    with zipfile.ZipFile(io.BytesIO(download.content)) as archive:
                        self.assertEqual(len(archive.namelist()), 4)
                        self.assertIn('全集简体.docx', archive.namelist())
                        for name in archive.namelist():
                            self.assertTrue(Document(io.BytesIO(archive.read(name))).paragraphs)
                if kind == 'domestic':
                    self.assertLess(visited.index('world'), visited.index('characters'))
                    self.assertLess(visited.index('characters'), visited.index('replacements'))
                    self.assertIn('localize', visited)
                if kind == 'original':
                    self.assertIn('reasoning', visited)
                    self.assertLess(visited.index('outline_all'), visited.index('script_1'))

    def test_locked_export_exact_text(self):
        locked = {'1': '已锁定。\n保持标点！  两个空格'}
        pid = self.create('foreign', 3, 2, locked)
        self.finish(pid)
        r = self.client.get(f'/api/projects/{pid}/export')
        self.assertEqual(r.status_code, 200)
        doc = Document(io.BytesIO(r.content))
        text = '\n'.join(p.text for p in doc.paragraphs)
        self.assertIn(locked['1'], text)
        self.assertNotIn('1', self.store.get(pid)['scripts'])

    def test_concurrent_confirmation_idempotency(self):
        pid = self.create()
        p = self.store.get(pid)
        body = dict(version=p['version'], action_id='same', action='confirm', answers={})
        with ThreadPoolExecutor(max_workers=4) as pool:
            results = list(pool.map(lambda _: self.service.action(pid, **body), range(4)))
        self.assertTrue(all(r['cursor'] == 1 for r in results))
        self.assertEqual(self.store.get(pid)['cursor'], 1)
        body['answers'] = {'changed': True}
        r = self.client.post(f'/api/projects/{pid}/actions', json=body)
        self.assertEqual(r.status_code, 409)

    def test_waiting_card_message_and_replay(self):
        pid = self.create()
        body = {'client_id': 'm1', 'text': '加爱情线'}
        for _ in range(2):
            self.assertEqual(self.client.post(f'/api/projects/{pid}/messages', json=body).status_code, 200)
        p = self.store.get(pid)
        self.assertEqual(p['cursor'], 0)
        self.assertEqual(len(p['requirements']), 1)
        self.assertEqual(len(p['messages']), 2)

    def test_budget_prevents_call(self):
        pid = self.create()
        self.client.put(f'/api/projects/{pid}/budget', json={'cap': 0})
        self.act(pid)
        asyncio.run(self.service.run_one(pid))
        p = self.store.get(pid)
        self.assertEqual(p['events'][-1]['code'], 'BUDGET_LIMIT')
        self.assertEqual(len(p['runs']), 0)

    def test_pause_resume_waiting_and_ready(self):
        pid = self.create()
        self.assertEqual(self.act(pid, 'pause').status_code, 200)
        self.assertEqual(self.act(pid, 'resume').json()['status'], 'waiting')
        self.act(pid)
        self.act(pid, 'pause')
        self.assertEqual(self.act(pid, 'resume').json()['status'], 'ready')

    def test_failure_keeps_reservation_and_reconcile_is_idempotent(self):
        class FailingProvider(TestProvider):
            async def generate(self, payload):
                raise TimeoutError()
        self.service.provider = FailingProvider()
        pid = self.create()
        self.act(pid)
        asyncio.run(self.service.run_one(pid))
        p = self.store.get(pid)
        self.assertEqual(p['status'], 'failed')
        self.assertEqual(p['budget']['reserved'], 0.01)
        run_id = p['runs'][0]['id']
        for _ in range(2):
            r = self.client.post(f'/api/projects/{pid}/runs/{run_id}/reconcile', json={'cost': 0.004})
            self.assertEqual(r.status_code, 200)
        budget = self.store.get(pid)['budget']
        self.assertEqual(budget['spent'], 0.004)
        self.assertEqual(budget['reserved'], 0)

    def test_requirement_during_running_is_not_lost(self):
        owner = self
        class UpdatingProvider(TestProvider):
            async def generate(self, payload):
                owner.service.message(pid, 'during-run', '加入日常线')
                return await super().generate(payload)
        self.service.provider = UpdatingProvider()
        pid = self.create()
        self.act(pid)
        asyncio.run(self.service.run_one(pid))
        p = self.store.get(pid)
        self.assertEqual(p['status'], 'waiting')
        self.assertEqual(p['requirements'][0]['text'], '加入日常线')

    def test_delivery_locks_actions(self):
        pid = self.create(total=1)
        self.finish(pid)
        self.assertEqual(self.act(pid, 'revise', {'feedback': '改写', 'episode': 1}).status_code, 409)

    def test_auth_and_no_frontend(self):
        r = self.client.get('/api/projects', headers={'Authorization': 'Bearer wrong'})
        self.assertEqual(r.status_code, 401)
        self.assertEqual(self.client.get('/').status_code, 404)

    def test_mode_has_no_default(self):
        pid = self.create('transcribe', total=1)
        self.act(pid)
        self.assertEqual(self.act(pid, answers={}).status_code, 422)
        self.assertEqual(current(self.store.get(pid))['key'], 'mode')

    def test_reject_lock_overwrite_from_model(self):
        pid = self.create('foreign', 2, 2, {'1': '保持原样'})
        with self.assertRaises(Exception):
            self.service.validate(self.store.get(pid), {'content': 'x', 'scripts': {'1': '被改写'}})

    def test_stale_card(self):
        pid = self.create()
        self.act(pid)
        r = self.client.post(f'/api/projects/{pid}/actions', json=dict(
            version=1, action_id='old-card', action='confirm', answers={}))
        self.assertEqual(r.status_code, 409)

    def test_transfer_is_explicit(self):
        pid = self.create('transcribe', 1)
        self.finish(pid)
        self.assertEqual(len(self.store.all()), 1)
        r = self.client.post(f'/api/projects/{pid}/transfer', json={'kind': 'foreign', 'title': '新改编'})
        self.assertEqual(r.status_code, 201)
        self.assertEqual(r.json()['stage']['key'], 'recap')
        self.assertEqual(len(self.store.all()), 2)

    def test_binary_file_requires_actual_parser(self):
        pid = self.create()
        self.client.post(f'/api/projects/{pid}/attachments', params={'name': 'video.mp4'}, content=b'video')
        self.act(pid)
        asyncio.run(self.service.run_one(pid))
        self.assertEqual(self.store.get(pid)['events'][-1]['code'], 'MEDIA_ADAPTER_REQUIRED')


if __name__ == '__main__':
    unittest.main()
