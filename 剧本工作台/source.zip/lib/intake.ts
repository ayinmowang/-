import type { Project } from './types';

type LockedReader = (file: Project['attachments'][number], count: number) => Promise<Record<string, string>>;

export async function creationRequest(p: Project, read: LockedReader) {
  const count = p.lockedEpisodes || 0;
  const locked: Record<string, string> = {};
  const files = p.attachments.filter(file => file.role === 'locked');
  if (count || files.length) {
    if (!count || !['foreign', 'domestic'].includes(p.kind)) throw new Error('LOCKED_RANGE_REQUIRED');
    for (const file of files) {
      for (const [episode, text] of Object.entries(await read(file, count))) {
        const n = Number(episode);
        if (!Number.isInteger(n) || String(n) !== episode || n < 1 || n > count ||
          episode in locked || typeof text !== 'string' || !text.trim()) throw new Error('LOCKED_RANGE_REQUIRED');
        locked[episode] = text;
      }
    }
    if (Object.keys(locked).length !== count) throw new Error('LOCKED_RANGE_REQUIRED');
  }
  return { title: p.title, kind: p.kind, total: p.total, start: count + 1, locked, brief: p.brief,
    ...(p.kind === 'transcribe' ? { transcribe_scope_choice: true } : {}) };
}
