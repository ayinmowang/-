import { env } from 'cloudflare:workers';
import { getChatGPTUser } from '../app/chatgpt-auth';
import type { Project } from './types';
export function bindings(): any { return env; }
export async function owner() {
  const user=await getChatGPTUser();
  if(!user) throw new Error('AUTH_REQUIRED');
  return user.userId;
}
export async function getProject(id:string,user:string):Promise<Project> {
  const row:any=await bindings().DB.prepare('SELECT data, version FROM studio_projects WHERE id=? AND owner=?').bind(id,user).first();
  if(!row) throw new Error('NOT_FOUND');
  return {...JSON.parse(row.data),version:row.version};
}
export async function saveProject(p:Project,user:string) {
  const version=p.version;p.updatedAt=new Date().toISOString();
  const result=await bindings().DB.prepare('UPDATE studio_projects SET data=?,version=version+1,updated_at=? WHERE id=? AND owner=? AND version=?').bind(JSON.stringify(p),p.updatedAt,p.id,user,version).run();
  if(!result.meta.changes)throw new Error('CONFLICT');
  p.version=version+1;return p;
}
export function message(p:Project,role:'user'|'director',text:string) {p.messages.push({id:crypto.randomUUID(),role,text,time:new Date().toISOString()});}
export function connected(){return Boolean(bindings().DRAMA_API_URL&&bindings().DRAMA_API_TOKEN);}
export async function backend(path:string,method='GET',body?:any,raw=false){
  if(!connected())throw new Error('SERVICE_NOT_CONNECTED');
  const response=await fetch(bindings().DRAMA_API_URL.replace(/\/$/,'')+path,{method,
    headers:{Authorization:'Bearer '+bindings().DRAMA_API_TOKEN,...(!raw&&body?{'Content-Type':'application/json'}:{})},
    body:body?(raw?body:JSON.stringify(body)):undefined});
  if(!response.ok)throw new Error('BACKEND_REQUEST_FAILED');
  return response;
}
export function failure(error:unknown){
 const code=error instanceof Error?error.message:'REQUEST_FAILED';
 const known=['AUTH_REQUIRED','NOT_FOUND','CONFLICT','SERVICE_NOT_CONNECTED','BACKEND_REQUEST_FAILED','INVALID_INPUT','FILE_TOO_LARGE','EPISODE_ALREADY_USED','EPISODE_MAPPING_REQUIRED'];
 return Response.json({error:known.includes(code)?code:'REQUEST_FAILED'},{status:code==='AUTH_REQUIRED'?401:code==='NOT_FOUND'?404:code==='CONFLICT'?409:code==='SERVICE_NOT_CONNECTED'?503:400});
}
