export type Kind = 'foreign'|'domestic'|'original'|'transcribe';
export type Message = { id:string; role:'user'|'director'; text:string; time:string };
export type Attachment = {id:string; name:string; size:number; type:string; text?:string; episode?:number};
export type Project = {id:string; title:string; kind:Kind; total:number|null; brief:string; messages:Message[]; attachments:Attachment[]; requirements:string[]; archived:boolean; createdAt:string; updatedAt:string; version:number; confirmed:boolean; remoteId?:string; remote?:any};
export const flows = [
 {kind:'foreign' as Kind,title:'国外迭代国外',description:'保留故事内核，重塑情节与人物',tag:'改编创作',icon:'globe'},
 {kind:'domestic' as Kind,title:'国内迭代国外',description:'跨越文化语境，让故事自然出海',tag:'出海改编',icon:'compass'},
 {kind:'transcribe' as Kind,title:'扒剧',description:'从视频素材，还原完整剧本',tag:'素材整理',icon:'film'},
 {kind:'original' as Kind,title:'原创',description:'把一个脑洞，写成一部新故事',tag:'从零创作',icon:'sparkles'},
];
