import type { Project, RemoteState, WorkflowCard } from './types';

type Generate = (turn: string, instruction: string, details: string) => Promise<string>;
function card(step: string, version: number, title: string, fields: string[]): WorkflowCard {
  return { id: step + '-' + version, step, title, fields, version };
}

export async function startTrial(p: Project, generate: Generate): Promise<RemoteState> {
  if (p.kind === 'transcribe') throw new Error('SERVICE_NOT_CONNECTED');
  const content = await generate('recap', '你是总编剧。根据用户的创作要求复述方向，给出两条具体建议。只描述收到的文字，附件名不能当成已读内容。', p.brief);
  return { id:'gpt-test-'+p.id, mode:'gpt_test', version:1, status:'waiting_confirm',cursor:0,
    stage:{key:'trial_recap',title:'文字试写 · 核对方向'},progress:{completed_steps:0,total_steps:2},
    card:card('trial_recap',1,'确认试写方向',[]), messages:[],
    outputs:{recap:{title:'试写方向',content,version:1,updatedAt:new Date().toISOString()}} };
}

export async function advanceTrial(p: Project, action: {action: string; version: number; answers?: Record<string,unknown>}, generate: Generate) {
  const r = p.remote!;
  if (action.version !== r.version) throw new Error('CONFLICT');
  if (!r.card || !['confirm','revise'].includes(action.action)) throw new Error('INVALID_INPUT');
  const reviewing = r.stage.key === 'trial_sample';
  const revising = action.action === 'revise';
  if (revising && !String(action.answers?.feedback || '').trim()) throw new Error('INVALID_INPUT');
  if (r.stage.key === 'trial_complete') throw new Error('INVALID_INPUT');
  if (reviewing && !revising) {
    r.version++; r.cursor=2; r.stage={key:'trial_complete',title:'试写已确认'};
    r.status='idle'; r.card=null; r.progress={completed_steps:2,total_steps:2};
    return;
  }
  const details = JSON.stringify({ decisions:action.answers ?? {}, previous:r.outputs.sample?.content || r.outputs.recap?.content });
  const content = await generate('sample-'+r.version,
    '你是总编剧。根据项目说明、确认决定和修改意见，写一个可审阅的中文短剧分场样稿，包括人物、场头、动作和对白。只使用给出的文字，不声称已读其他附件或完成整剧。',details);
  r.version++; r.cursor=1; r.status='waiting_confirm'; r.stage={key:'trial_sample',title:'审阅试写样稿'};
  r.outputs.sample={title:'试写样稿',content,version:(r.outputs.sample?.version || 0)+1,updatedAt:new Date().toISOString()};
  r.card=card('trial_sample',r.version,'验收样稿或填写修改意见',[]);
  r.progress={completed_steps:1,total_steps:2};
}
