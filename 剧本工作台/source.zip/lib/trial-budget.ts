async function ledger(db: any) {
  await db.batch([
    db.prepare('CREATE TABLE IF NOT EXISTS studio_trial_caps (project TEXT PRIMARY KEY, cap INTEGER NOT NULL)'),
    db.prepare('CREATE TABLE IF NOT EXISTS studio_trial_calls (project TEXT, turn TEXT, reserved INTEGER NOT NULL, spent INTEGER NOT NULL DEFAULT 0, reply TEXT, PRIMARY KEY(project,turn))'),
  ]);
  return db;
}

export async function trialRows(env: any) {
  const db = await ledger(env.DB);
  const { results } = await db.prepare(`SELECT p.id, json_extract(p.data,'$.title') title, p.version,
    COALESCE(c.cap,0) cap, COALESCE(SUM(t.spent),0) spent, COALESCE(SUM(t.reserved),0) reserved
    FROM studio_projects p LEFT JOIN studio_trial_caps c ON c.project=p.id LEFT JOIN studio_trial_calls t ON t.project=p.id
    WHERE json_extract(p.data,'$.kind') != 'transcribe' AND (json_extract(p.data,'$.remoteId') IS NULL OR json_extract(p.data,'$.remoteId') LIKE 'gpt-test-%')
    GROUP BY p.id ORDER BY p.updated_at DESC`).all();
  return results.map((r: any) => ({ id:r.id, title:r.title, version:r.version, stage:'文字试写', status:'trial', running:0, retries:0,
    budget:{cap:r.cap/1e6, spent:r.spent/1e6, reserved:r.reserved/1e6} }));
}

export async function setTrialCap(env: any, id: string, usd: number) {
  const db = await ledger(env.DB);
  const cap = Math.round(usd * 1e6);
  const result = await db.prepare(`INSERT INTO studio_trial_caps(project,cap) SELECT id,? FROM studio_projects WHERE id=?
    AND ? >= (SELECT COALESCE(SUM(reserved+spent),0) FROM studio_trial_calls WHERE project=?)
    ON CONFLICT(project) DO UPDATE SET cap=excluded.cap`).bind(cap,id,cap,id).run();
  if (!result.meta.changes) throw new Error('CAP_BELOW_COMMITTED');
}

export async function trialText(env: any, project: string, turn: string, context: string, instruction: string): Promise<string> {
  const db = await ledger(env.DB);
  const old = await db.prepare('SELECT reply FROM studio_trial_calls WHERE project=? AND turn=?').bind(project,turn).first();
  if (old?.reply) return old.reply;
  if (old) throw new Error('TRIAL_PENDING');
  const b = env;
  const key = b.OPENAI_API_KEY || process.env.OPENAI_API_KEY;
  const model = b.OPENAI_MODEL || process.env.OPENAI_MODEL;
  const rates = ['INPUT_USD_PER_MILLION','OUTPUT_USD_PER_MILLION'].map(k=>Number(b[k] || process.env[k]));
  if (!key || !model || rates.some(n=>!Number.isFinite(n) || n<=0)) throw new Error('TRIAL_CONFIGURATION');
  const messages = [{role:'system',content:instruction},{role:'user',content:context}];
  const bytes = new TextEncoder().encode(JSON.stringify(messages)).length;
  if (bytes > 100000) throw new Error('TRIAL_CONTEXT_LIMIT');
  const max = 1800;
  const reserve = Math.ceil((bytes+2048)*rates[0]+max*rates[1]);
  const result = await db.prepare(`INSERT OR IGNORE INTO studio_trial_calls(project,turn,reserved)
    SELECT project,?,? FROM studio_trial_caps WHERE project=?
    AND cap >= ? + (SELECT COALESCE(SUM(reserved+spent),0) FROM studio_trial_calls WHERE project=?)`).bind(turn,reserve,project,reserve,project).run();
  if (!result.meta.changes) {
    const existing = await db.prepare('SELECT reply FROM studio_trial_calls WHERE project=? AND turn=?').bind(project,turn).first();
    if (existing?.reply) return existing.reply;
    throw new Error(existing ? 'TRIAL_PENDING' : 'BUDGET_EXCEEDED');
  }
  const base = String(b.OPENAI_BASE_URL || process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/+$/,'');
  const response = await fetch(base + '/chat/completions',{method:'POST', headers:{'Content-Type':'application/json',Authorization:'Bearer '+key},
    body:JSON.stringify({model,messages,max_completion_tokens:max}), signal:AbortSignal.timeout(90000)});
  if (!response.ok) {
    if ([400,401,403,404,429].includes(response.status)) {
      await db.prepare('DELETE FROM studio_trial_calls WHERE project=? AND turn=?').bind(project,turn).run();
    }
    throw new Error('BACKEND_REQUEST_FAILED');
  }
  const data = await response.json() as any;
  const usage = data.usage;
  const cost = usage && Number.isSafeInteger(usage.prompt_tokens) && Number.isSafeInteger(usage.completion_tokens)
    ? Math.ceil(usage.prompt_tokens*rates[0]+usage.completion_tokens*rates[1]) : reserve;
  const reply = data.choices?.[0]?.finish_reason === 'stop' && data.choices[0].message?.content?.trim();
  await db.prepare('UPDATE studio_trial_calls SET reserved=0, spent=?, reply=?, turn=? WHERE project=? AND turn=?')
    .bind(cost,reply || null,reply ? turn : turn + '-incomplete-' + crypto.randomUUID(),project,turn).run();
  if (!reply) throw new Error('BACKEND_REQUEST_FAILED');
  return reply;
}
