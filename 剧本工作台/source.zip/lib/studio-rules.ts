const SENSITIVE_KEYS = new Set([
  'model',
  'model_name',
  'provider',
  'route',
  'line',
  'tokens',
  'prompt_tokens',
  'completion_tokens',
  'total_tokens',
  'system_prompt',
  'raw_prompt',
  'api_key',
]);

export function sanitizePayload<T>(input: T): T {
  if (input === null || input === undefined) return input;
  if (typeof input === 'string') {
    return input
      .replace(/\b(gpt-4[a-z0-9.-]*|gpt-5[a-z0-9.-]*|claude-[a-z0-9.-]+|gemini-[a-z0-9.-]+|deepseek-[a-z0-9.-]+|grok-[a-z0-9.-]+)\b/gi, '创作引擎')
      .replace(/\b(prompt_tokens|completion_tokens|total_tokens)\s*[:=]\s*\d+/gi, '') as unknown as T;
  }
  if (Array.isArray(input)) return input.map((x) => sanitizePayload(x)) as unknown as T;
  if (typeof input === 'object') {
    const out: Record<string, any> = {};
    for (const [k, v] of Object.entries(input as Record<string, any>)) {
      if (SENSITIVE_KEYS.has(k.toLowerCase())) continue;
      out[k] = sanitizePayload(v);
    }
    return out as T;
  }
  return input;
}

export function statedTotal(text: string): number | null {
  const match =
    text.match(/(?:全剧|整个剧|总共|一共|总集数|全本|共)\s*(?:是|有|为|：|:)?\s*(\d{1,3})\s*集/) ||
    text.match(/写到\s*第?\s*(\d{1,3})\s*集/) ||
    text.trim().match(/^(\d{1,3})\s*集[。！!]?$/);
  const n = Number(match?.[1]);
  return Number.isInteger(n) && n >= 1 && n <= 300 ? n : null;
}

export function statedLocked(text: string): number | null {
  const match =
    text.match(/前\s*(\d{1,3})\s*集\s*(?:已|已经)?\s*(?:锁定|定稿|不改|不动)/) ||
    text.match(/(?:锁定|定稿)\s*前\s*(\d{1,3})\s*集/) ||
    text.match(/第?\s*1\s*[-~至到]\s*(\d{1,3})\s*集\s*(?:已|已经)?\s*(?:锁定|定稿|不改|不动)/);
  const n = Number(match?.[1]);
  return Number.isInteger(n) && n >= 1 && n <= 299 ? n : null;
}

export function isProgressQuery(text: string): boolean {
  const t = text.trim();
  if (t.length > 36) return false;
  return /^(现在|目前|请问|这剧)?(进度)?(咋样了?|怎么样了?|还要多久|什么时候好|啥时候.*答复|到哪一步了?|在跑吗|卡在哪了?|进度)[？?。！!]*$/.test(t);
}

export function detectEpisodeFromName(name: string): number | undefined {
  // Strip extension
  const base = name.replace(/\.[^.]+$/, '').trim();
  // Do NOT guess composite scene names like "1-1" or "20261113" or "微信视频2026..."
  if (/^\d+\s*[-_]\s*\d+$/.test(base) || /微信视频|WeChat|\d{6,}/i.test(base)) {
    return undefined;
  }
  const match =
    base.match(/(?:第|^|[_\-\s])0*(\d{1,3})\s*集/) ||
    base.match(/(?:^|[_\-\s])(?:ep|episode)\s*0*(\d{1,3})(?:$|[_\-\s])/i) ||
    base.match(/^0*(\d{1,3})$/);
  const n = Number(match?.[1]);
  return Number.isInteger(n) && n >= 1 && n <= 300 ? n : undefined;
}
