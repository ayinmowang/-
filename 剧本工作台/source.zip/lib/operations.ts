import { getChatGPTUser } from '../app/chatgpt-auth';
import { bindings } from './server';

export async function adminAccess() {
  const user = await getChatGPTUser();
  if (!user) return 'guest';
  const b = bindings();
  return user.userId === b.STUDIO_ADMIN_USER_ID ||
    Boolean(b.STUDIO_ADMIN_EMAIL && user.email.toLowerCase() === String(b.STUDIO_ADMIN_EMAIL).trim().toLowerCase())
    ? 'admin' : 'denied';
}
