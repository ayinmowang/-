import assert from 'node:assert/strict';

function statedTotal(text) {
  const match =
    text.match(/(?:全剧|整个剧|总共|一共|总集数|全本|共)\s*(?:是|有|为|：|:)?\s*(\d{1,3})\s*集/) ||
    text.match(/写到\s*第?\s*(\d{1,3})\s*集/) ||
    text.trim().match(/^(\d{1,3})\s*集[。！!]?$/);
  const n = Number(match?.[1]);
  return Number.isInteger(n) && n >= 1 && n <= 300 ? n : null;
}

function statedLocked(text) {
  const match =
    text.match(/前\s*(\d{1,3})\s*集\s*(?:已|已经)?\s*(?:锁定|定稿|不改|不动)/) ||
    text.match(/(?:锁定|定稿)\s*前\s*(\d{1,3})\s*集/) ||
    text.match(/第?\s*1\s*[-~至到]\s*(\d{1,3})\s*集\s*(?:已|已经)?\s*(?:锁定|定稿|不改|不动)/);
  const n = Number(match?.[1]);
  return Number.isInteger(n) && n >= 1 && n <= 299 ? n : null;
}

function detectEpisodeFromName(name) {
  const base = name.replace(/\.[^.]+$/, '').trim();
  if (/^\d+\s*[-_]\s*\d+$/.test(base) || /微信视频|WeChat|\d{6,}/i.test(base)) {
    return undefined;
  }
  const match =
    base.match(/(?:第|^|[_\-\s])0*(\d{1,3})\s*集/) ||
    base.match(/(?:^|[_\-\s])(?:ep|episode)\s*0*(\d{1,3})(?:$|[_\-\s])/i) ||
    base.match(/^0*(\d{1,3})$/);
  const n = Number(match?.[1]);
  return Number.isInteger(n) && n >= 1 && n <= 300 ? n : undefined;
}

function isProgressQuery(text) {
  const t = text.trim();
  if (t.length > 36) return false;
  return /^(现在|目前|请问|这剧)?(进度)?(咋样了?|怎么样了?|还要多久|什么时候好|啥时候.*答复|到哪一步了?|在跑吗|卡在哪了?|进度)[？?。！!]*$/.test(t);
}

const SENSITIVE_KEYS = new Set([
  'model', 'model_name', 'provider', 'route', 'line',
  'tokens', 'prompt_tokens', 'completion_tokens', 'total_tokens',
  'system_prompt', 'raw_prompt', 'api_key',
]);

function sanitizePayload(input) {
  if (input === null || input === undefined) return input;
  if (typeof input === 'string') {
    return input
      .replace(/\b(gpt-4[a-z0-9.-]*|gpt-5[a-z0-9.-]*|claude-[a-z0-9.-]+|gemini-[a-z0-9.-]+|deepseek-[a-z0-9.-]+|grok-[a-z0-9.-]+)\b/gi, '创作引擎')
      .replace(/\b(prompt_tokens|completion_tokens|total_tokens)\s*[:=]\s*\d+/gi, '');
  }
  if (Array.isArray(input)) return input.map((x) => sanitizePayload(x));
  if (typeof input === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(input)) {
      if (SENSITIVE_KEYS.has(k.toLowerCase())) continue;
      out[k] = sanitizePayload(v);
    }
    return out;
  }
  return input;
}

// 1. Test statedTotal & statedLocked for continuation workflow
assert.equal(statedTotal('全剧 62 集，前 10 集已锁定，帮我续写后面'), 62);
assert.equal(statedLocked('全剧 62 集，前 10 集已锁定，帮我续写后面'), 10);
assert.equal(statedLocked('第1-15集已定稿，后面写到第80集'), 15);
assert.equal(statedTotal('第1-15集已定稿，后面写到第80集'), 80);
assert.equal(statedTotal('我有一个都市爱情故事的脑洞'), null);

// 2. Test transcribe filename detection (avoid false positives on 1-1.mp4 & WeChat videos)
assert.equal(detectEpisodeFromName('第08集.mp4'), 8);
assert.equal(detectEpisodeFromName('EP12.mp4'), 12);
assert.equal(detectEpisodeFromName('05.mp4'), 5);
assert.equal(detectEpisodeFromName('1-1.mp4'), undefined);
assert.equal(detectEpisodeFromName('微信视频20261113.mp4'), undefined);

// 3. Test progress query detection (G14 honesty check)
assert.equal(isProgressQuery('进度'), true);
assert.equal(isProgressQuery('现在进度咋样了？'), true);
assert.equal(isProgressQuery('啥时候给我答复'), true);
assert.equal(isProgressQuery('女主性格要更冷酷一点，不要恋爱脑'), false);

// 4. Test redline sanitization (no model names, routes, tokens, or prompts leaked)
const rawBackendObj = {
  id: 'proj-1',
  model: 'claude-opus-4-6',
  prompt_tokens: 12345,
  system_prompt: 'secret system prompt',
  text: '由 gpt-4o-mini 与 deepseek-reasoner 处理完成，total_tokens: 900',
};
const cleaned = sanitizePayload(rawBackendObj);
assert.equal('model' in cleaned, false);
assert.equal('prompt_tokens' in cleaned, false);
assert.equal('system_prompt' in cleaned, false);
assert.equal(cleaned.text.includes('gpt-4o-mini'), false);
assert.equal(cleaned.text.includes('deepseek-reasoner'), false);
assert.equal(cleaned.text.includes('total_tokens'), false);

console.log('ALL_CONTRACT_TESTS_PASSED');
