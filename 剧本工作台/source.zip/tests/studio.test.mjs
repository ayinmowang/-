import assert from 'node:assert/strict';

import { statedTotal, statedLocked, detectEpisodeFromName, isProgressQuery, sanitizePayload } from '../lib/studio-rules.ts';

// 1. Test statedTotal & statedLocked for continuation workflow
assert.equal(statedTotal('全剧 62 集，前 10 集已锁定，帮我续写后面'), 62);
assert.equal(statedLocked('全剧 62 集，前 10 集已锁定，帮我续写后面'), 10);
assert.equal(statedLocked('第1-15集已定稿，后面写到第80集'), 15);
assert.equal(statedTotal('第1-15集已定稿，后面写到第80集'), 80);
assert.equal(statedTotal('我有一个都市爱情故事的脑洞'), null);

// 2. Test transcribe filename detection (avoid false positives on 1-1.mp4 & WeChat videos)
assert.equal(detectEpisodeFromName('第08集.mp4'), 8);
assert.equal(detectEpisodeFromName('EP12.mp4'), 12);
assert.equal(detectEpisodeFromName('05.mp4'), 5);
assert.equal(detectEpisodeFromName('1-1.mp4'), undefined);
assert.equal(detectEpisodeFromName('微信视频20261113.mp4'), undefined);

// 3. Test progress query detection (G14 honesty check)
assert.equal(isProgressQuery('进度'), true);
assert.equal(isProgressQuery('现在进度咋样了？'), true);
assert.equal(isProgressQuery('啥时候给我答复'), true);
assert.equal(isProgressQuery('女主性格要更冷酷一点，不要恋爱脑'), false);

// 4. Test redline sanitization (no model names, routes, tokens, or prompts leaked)
const rawBackendObj = {
  id: 'proj-1',
  model: 'claude-opus-4-6',
  prompt_tokens: 12345,
  system_prompt: 'secret system prompt',
  text: '由 gpt-4o-mini 与 deepseek-reasoner 处理完成，total_tokens: 900',
};
const cleaned = sanitizePayload(rawBackendObj);
assert.equal('model' in cleaned, false);
assert.equal('prompt_tokens' in cleaned, false);
assert.equal('system_prompt' in cleaned, false);
assert.equal(cleaned.text.includes('gpt-4o-mini'), false);
assert.equal(cleaned.text.includes('deepseek-reasoner'), false);
assert.equal(cleaned.text.includes('total_tokens'), false);

console.log('ALL_CONTRACT_TESTS_PASSED');

const { creationRequest } = await import('../lib/intake.ts');
const { startTrial, advanceTrial } = await import('../lib/trial-flow.ts');
const project = { id:'fixture', title:'合成项目', brief:'演员误拿剧本',kind:'original',total:null,attachments:[] };
assert.equal((await creationRequest(project, () => assert.fail())).total,null);
const continuation = {...project,kind:'foreign',total:3,lockedEpisodes:2,attachments:[{role:'locked'}]};
await assert.rejects(creationRequest(continuation,async()=>({'1':'甲'})),/LOCKED_RANGE_REQUIRED/);
assert.deepEqual((await creationRequest(continuation, async()=>({'1':'甲','2':'乙'}))).locked,{'1':'甲','2':'乙'});
const calls = [];
const generate = async (...args) => { calls.push(args); return '用于验证卡片的固定输出'; };
project.remote = await startTrial(project,generate);
await advanceTrial(project,{version:1,action:'confirm'},generate);
assert.equal(project.remote.stage.key,'trial_sample');
await assert.rejects(advanceTrial(project,{version:1,action:'confirm'},generate),/CONFLICT/);
await advanceTrial(project,{version:2,action:'revise',answers:{feedback:'保留沉默的结尾'}},generate);
assert.match(calls.at(-1)[2],/保留沉默的结尾/);
await advanceTrial(project,{version:3,action:'confirm'},generate);
assert.equal(project.remote.card,null);
assert.equal(project.remote.stage.key,'trial_complete');
assert.equal(calls.length,3);
console.log('INTAKE_AND_TRIAL_PASSED');

const { DatabaseSync } = await import('node:sqlite');
const { setTrialCap,trialText,trialRows } = await import('../lib/trial-budget.ts');
const sqlite = new DatabaseSync(':memory:');
sqlite.exec("CREATE TABLE studio_projects(id TEXT PRIMARY KEY,data TEXT,version INTEGER,updated_at TEXT); INSERT INTO studio_projects VALUES('fixture','{\"kind\":\"original\",\"title\":\"测试\"}',1,'now')");
const DB = { prepare(sql) {
  const stmt = sqlite.prepare(sql);
  let args = [];
  return {bind(...a){args=a;return this;}, run(){return {meta:stmt.run(...args)};}, first(){return stmt.get(...args);}, all(){return {results:stmt.all(...args)};}};
},batch(statements){for (const s of statements) s.run();} };
const env={DB,OPENAI_API_KEY:'test',OPENAI_MODEL:'fixture',INPUT_USD_PER_MILLION:1,OUTPUT_USD_PER_MILLION:2};
let requests=0;
const savedFetch=globalThis.fetch;
try {
  globalThis.fetch=async()=>{requests++;return Response.json({choices:[{finish_reason:'stop',message:{content:'测试输出'}}],usage:{prompt_tokens:100,completion_tokens:200}});};
  const call=()=>trialText(env,'fixture','turn','合成材料','测试');
  await assert.rejects(call(),/BUDGET_EXCEEDED/);
  assert.equal(requests,0);
  await setTrialCap(env,'fixture',0.01);
  await Promise.allSettled([call(),call()]);
  assert.equal(await call(),'测试输出');
  assert.equal(requests,1);
  assert.deepEqual((await trialRows(env))[0].budget,{cap:0.01,reserved:0,spent:0.0005});
  await assert.rejects(setTrialCap(env,'fixture',0),/CAP_BELOW_COMMITTED/);
} finally {globalThis.fetch=savedFetch;sqlite.close();}
console.log('TRIAL_BUDGET_PASSED');
