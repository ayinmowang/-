import { setTrialCap, trialRows } from '../../../lib/trial-budget';
import { adminAccess } from '../../../lib/operations';
import { bindings, backend, connected, failure, gptAvailable } from '../../../lib/server';

export async function GET() {
  if (await adminAccess() !== 'admin') return new Response(null, { status: 403 });
  try {
    const remote = connected() ? await (await backend('/api/admin/operations')).json() as any[] : [];
    const local = gptAvailable() && !connected() ? await trialRows(bindings()) : [];
    return Response.json({ connected: connected() || gptAvailable(), projects: [...remote, ...local] },
      { headers: { 'Cache-Control': 'private, no-store' } });
  } catch (e) { return failure(e); }
}

export async function POST(request: Request) {
  if (await adminAccess() !== 'admin') return new Response(null, { status: 403 });
  if (request.headers.get('origin') !== new URL(request.url).origin ||
    !request.headers.get('content-type')?.startsWith('application/json')) return new Response(null, { status: 403 });
  try {
    const { id, cap, operation, version, action_id } = await request.json() as any;
    if (operation === 'trial_budget' && typeof id === 'string' && /^[a-f0-9-]{36}$/.test(id) && Number.isFinite(cap) && cap >= 0 && cap <= 10000) {
      await setTrialCap(bindings(),id,cap);
      return Response.json({ ok:true });
    }
    if (typeof id !== 'string' || !/^[a-f0-9]{32}$/.test(id)) throw new Error('INVALID_INPUT');
    const path = '/api/projects/' + id;
    if (operation === 'budget' && Number.isFinite(cap) && cap >= 0 && cap <= 10000) {
      await backend(path + '/budget', 'PUT', { cap });
    } else if (operation === 'retry' && Number.isInteger(version) && typeof action_id === 'string') {
      await backend(path + '/actions', 'POST', { action: 'retry', action_id, version, answers: {} });
    } else throw new Error('INVALID_INPUT');
    return Response.json({ ok: true });
  } catch (e) { return failure(e); }
}
