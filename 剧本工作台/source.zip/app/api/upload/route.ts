import { detectEpisodeFromName } from '../../../lib/studio-rules';
import { bindings, owner, getProject, saveProject, message, failure, backend, backendEpisodeFile, connected } from '../../../lib/server';
import { episodeDeliveries } from '../../../lib/transcribe';
import type { RemoteState } from '../../../lib/types';

export function detectRoleFromName(name: string, kind: string): 'source' | 'locked' | 'setting' {
  if (kind === 'original') return 'setting';
  if (/(锁定|定稿|locked|前\d+集)/i.test(name)) return 'locked';
  if (/(设定|人物|大纲|参考|setting|bible)/i.test(name)) return 'setting';
  return 'source';
}

export async function GET(request: Request) {
  try {
    const user = await owner();
    const url = new URL(request.url);
    const id = url.searchParams.get('id');
    const fileId = url.searchParams.get('file');
    const isExport = url.searchParams.get('export') === '1';
    if (!id) throw new Error('INVALID_INPUT');
    const p = await getProject(id, user);

    if (url.searchParams.has('episode')) {
      const episode = Number(url.searchParams.get('episode'));
      if (p.kind !== 'transcribe' || !p.remoteId || !connected() || !Number.isInteger(episode) || episode < 1 || episode > 300) {
        throw new Error('NOT_FOUND');
      }
      const remote = await (await backend('/api/projects/' + encodeURIComponent(p.remoteId))).json() as RemoteState;
      const delivery = episodeDeliveries(remote).find(item => item.episode === episode);
      if (!delivery) throw new Error('NOT_FOUND');
      const document = await backendEpisodeFile(delivery.url);
      return new Response(document.body, { headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(`第${episode}集.docx`)}`,
        'Cache-Control': 'private, no-store',
      } });
    }

    if (isExport) {
      if (p.kind === 'transcribe') {
        if (!p.remoteId || !connected()) throw new Error('DELIVERY_NOT_READY');
        const archive = await backend('/api/projects/' + encodeURIComponent(p.remoteId) + '/export');
        if (!archive.body || !/^application\/zip(?:;|$)/i.test(archive.headers.get('content-type') || '')) {
          throw new Error('DELIVERY_NOT_READY');
        }
        return new Response(archive.body, { headers: {
          'Content-Type': 'application/zip',
          'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(p.title + '_扒剧交付.zip')}`,
          'Cache-Control': 'private, no-store',
        } });
      }
      if (!p.remoteId || !connected() || p.remoteId.startsWith('gpt-test-')) throw new Error('DELIVERY_NOT_READY');
      const document = await backendEpisodeFile('/api/projects/' + encodeURIComponent(p.remoteId) + '/export');
      return new Response(document.body, { headers: {
        'Content-Type': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(p.title + '.docx')}`,
        'Cache-Control': 'private, no-store',
      } });

    }

    if (fileId) {
      const att = p.attachments.find((a) => a.id === fileId);
      if (!att) throw new Error('NOT_FOUND');
      const obj = await bindings().BUCKET.get(`${user}/${p.id}/${att.id}`);
      if (!obj) throw new Error('SOURCE_FILE_MISSING');
      const buf = await obj.arrayBuffer();
      return new Response(buf, {
        status: 200,
        headers: {
          'Content-Type': att.type || 'application/octet-stream',
          'Content-Disposition': `attachment; filename="${encodeURIComponent(att.name)}"`,
        },
      });
    }

    throw new Error('INVALID_INPUT');
  } catch (e) {
    return failure(e);
  }
}

export async function POST(request: Request) {
  try {
    const user = await owner();
    const url = new URL(request.url);
    const id = url.searchParams.get('id');
    const name = url.searchParams.get('name') || '未命名素材';
    const explicitRole = url.searchParams.get('role') as 'source' | 'locked' | 'setting' | null;
    if (!id) throw new Error('INVALID_INPUT');

    const p = await getProject(id, user);
    const buf = await request.arrayBuffer();
    if (buf.byteLength > 20 * 1024 * 1024) throw new Error('FILE_TOO_LARGE');

    const attId = crypto.randomUUID();
    await bindings().BUCKET.put(`${user}/${p.id}/${attId}`, buf);

    let episode = p.kind === 'transcribe' ? detectEpisodeFromName(name) : undefined;
    // Prevent duplicate auto-assigned episode numbers
    if (episode !== undefined && p.attachments.some((a) => a.episode === episode)) {
      episode = undefined;
    }
    if (episode !== undefined && p.total !== null && episode > p.total) {
      episode = undefined;
    }

    const role = explicitRole || detectRoleFromName(name, p.kind);
    const attachment = {
      id: attId,
      name,
      size: buf.byteLength,
      type: request.headers.get('content-type') || 'application/octet-stream',
      role,
      episode,
      uploadedAt: new Date().toISOString(),
    };
    p.attachments.push(attachment);

    if (p.kind === 'transcribe') {
      if (episode !== undefined) {
        message(p, 'director', `已归档素材「${name}」，自动识别为第 ${episode} 集（可在右侧素材栏随时修改）。`);
      } else {
        message(p, 'director', `已归档素材「${name}」，未能从文件名确定唯一集号，请在下方「补录或核对素材集号」卡片中填写第几集。`);
      }
    } else {
      const roleText = role === 'locked' ? '前序锁定稿（一字不动）' : role === 'setting' ? '设定与参考资料' : '原稿素材';
      message(p, 'director', `已归档「${name}」（用途：${roleText}，可在右侧素材栏切换用途）。`);
    }

    return Response.json(await saveProject(p, user));
  } catch (e) {
    return failure(e);
  }
}
