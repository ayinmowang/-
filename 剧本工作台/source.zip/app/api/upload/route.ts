import { bindings,owner,getProject,saveProject,message,backend,failure } from '../../../lib/server';
export async function POST(request:Request){try{
 const user=await owner();const params=new URL(request.url).searchParams;const id=params.get('id')||'';const name=params.get('name')||'素材';
 const p=await getProject(id,user);const chunks:Uint8Array[]=[];let size=0;
 const reader=request.body?.getReader();if(!reader)throw new Error('INVALID_INPUT');
 while(true){const {done,value}=await reader.read();if(done)break;size+=value.byteLength;if(size>20*1024*1024){await reader.cancel();throw new Error('FILE_TOO_LARGE');}chunks.push(value);}
 if(!size)throw new Error('INVALID_INPUT');
 const data=new Uint8Array(size);let offset=0;for(const c of chunks){data.set(c,offset);offset+=c.byteLength;}
 const aid=crypto.randomUUID();
 const filename=name.replace(/\.[^.]+$/,'');
 const recognized=p.kind==='transcribe'?(filename.match(/(?:^|[\s._-])(?:第\s*)?(?:EP?|episode)\s*0*(\d{1,3})(?:\s*集)?(?:$|[\s._-])/i)||filename.match(/第\s*0*(\d{1,3})\s*集/)||filename.match(/^0*(\d{1,3})$/)):null;
 const proposed=Number(params.get('episode')||recognized?.[1])||undefined;
 const episode=proposed&&p.attachments.some(a=>a.episode===proposed)?undefined:proposed;
 if(episode&&(!Number.isInteger(episode)||episode<1||episode>(p.total??300)))throw new Error('INVALID_INPUT');
 await bindings().BUCKET.put(user+'/'+id+'/'+aid,data,{httpMetadata:{contentType:request.headers.get('content-type')||'application/octet-stream'}});
 p.attachments.push({id:aid,name,size,type:request.headers.get('content-type')||'',episode});
 if(p.remoteId)await backend('/api/projects/'+p.remoteId+'/attachments?name='+encodeURIComponent(aid+'-'+name)+'&role=source'+(episode?'&episode='+episode:''),'POST',data,true);
 message(p,'director',`已保存「${name}」。${p.kind==='transcribe'?(episode?`识别为第 ${episode} 集。`:'文件名里没有明确集号，请在下方补录。'):''}${p.remoteId?'材料已同步到创作后端。':'原文件已归档，生成服务接入后进行内容解析。'}`);
 return Response.json(await saveProject(p,user));
}catch(e){return failure(e);}}
export async function GET(request:Request){try{
 const user=await owner();const params=new URL(request.url).searchParams;const p=await getProject(params.get('id')||'',user);
 if(params.get('export')==='1'){
  if(!p.remoteId)throw new Error('SERVICE_NOT_CONNECTED');
  const result=await backend('/api/projects/'+p.remoteId+'/export');return new Response(result.body,{headers:result.headers});
 }
 const aid=params.get('file');const a=p.attachments.find(a=>a.id===aid);if(!a)throw new Error('NOT_FOUND');
 const object=await bindings().BUCKET.get(user+'/'+p.id+'/'+aid);if(!object)throw new Error('NOT_FOUND');
 return new Response(object.body,{headers:{'Content-Type':'application/octet-stream','Content-Disposition':`attachment; filename*=UTF-8''${encodeURIComponent(a.name)}`}});
}catch(e){return failure(e);}}
