import { chatGPTSignInPath } from '../chatgpt-auth';
import { adminAccess } from '../../lib/operations';
import Operations from './operations';

export const dynamic = 'force-dynamic';

export default async function AdminPage() {
  const access = await adminAccess();

  return (
    <main className="admin-shell">
      <section className="workspace-hud">
        <a className="workspace-download" href="/">← 返回总编剧工作台</a>
        <h1>管理后台</h1>
        {access === 'guest' ? (
          <a className="workspace-download" href={chatGPTSignInPath('/admin')}>登录后台</a>
        ) : access !== 'admin' ? (
          <p>此页面需要工作台管理员权限。</p>
        ) : (
          <Operations />
        )}
      </section>
    </main>
  );
}
