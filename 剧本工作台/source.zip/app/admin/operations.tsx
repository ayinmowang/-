'use client';
import { useEffect, useState } from 'react';

type Row = { id: string; title: string; status: string; version: number; stage: string; running: number; retries: number;
  error?: string; budget: { cap: number; spent: number; reserved: number } };

export default function Operations() {
  const [rows, setRows] = useState<Row[]>([]);
  const [state, setState] = useState('loading');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);
  async function refresh() {
    try {
      const res = await fetch('/api/admin', { cache: 'no-store' });
      if (!res.ok) throw new Error();
      const data = await res.json() as { connected: boolean; projects: Row[] };
      setRows(data.projects); setState(data.connected ? 'ready' : 'offline');
    } catch { setState('error'); }
  }
  useEffect(() => { void refresh(); }, []);
  async function submit(payload: object) {
    setBusy(true); setNotice('');
    try {
      const res = await fetch('/api/admin', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      if (!res.ok) {
        const err = await res.json().catch(() => ({})) as {error?: string};
        throw new Error(err.error === 'CAP_BELOW_COMMITTED' ? '上限不能低于已用与预留之和。' : '提交失败，请刷新项目状态后重试。');
      }
      setNotice('已保存操作。'); await refresh();
    } catch (err) { setNotice(err instanceof Error ? err.message : '操作失败'); }
    finally { setBusy(false); }
  }
  return <section aria-label="项目运行与额度">
    <button className="secondary" disabled={busy} onClick={() => void refresh()}>刷新状态</button>
    <p role="status">{notice || ({ loading:'正在读取项目…', offline:'创作服务待连接。请在站点设置中配置服务地址与访问令牌。', error:'暂时读不到创作服务，请检查连接后刷新。', ready: rows.length ? '正在运行的任务：' + rows.reduce((n,p) => n+p.running,0) : '还没有连接到创作服务的项目。' }[state])}</p>
    {state === 'ready' && rows.map(p => <article key={p.id} className="ops-project">
      <h2>{p.title}</h2><p>{p.stage} · 运行 {p.running} 项 · 已重试 {p.retries} 次</p>
      <p>已用 ${p.budget.spent.toFixed(4)} · 预留 ${p.budget.reserved.toFixed(4)} · 上限 ${p.budget.cap.toFixed(2)}</p>
      <form onSubmit={event => { event.preventDefault(); const cap = Number(new FormData(event.currentTarget).get('cap')); void submit({ operation:p.status === 'trial' ? 'trial_budget' : 'budget', id:p.id, cap }); }}>
        <label>项目上限（美元） <input name="cap" key={p.budget.cap} type="number" required min="0" max="10000" step="0.01" defaultValue={p.budget.cap} /></label>
        <button className="secondary" disabled={busy}>保存额度</button>
      </form>
      {p.status === 'failed' && <><p>{p.error || '当前步骤失败'}</p><button className="secondary" disabled={busy} onClick={() => void submit({ operation:'retry', id:p.id, version:p.version, action_id:crypto.randomUUID() })}>重试当前步骤</button></>}
    </article>)}
  </section>;
}
