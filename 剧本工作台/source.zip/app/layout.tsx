import type { Metadata } from 'next';
import './globals.css';
export const metadata:Metadata={title:'总编剧 · Story Studio',description:'从一个想法，到一部好剧。你的 AI 短剧创作工作台。'};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="zh-CN"><body>{children}</body></html>;}
